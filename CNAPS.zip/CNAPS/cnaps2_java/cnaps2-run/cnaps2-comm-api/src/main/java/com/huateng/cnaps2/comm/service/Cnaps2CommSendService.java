package com.huateng.cnaps2.comm.service;

import java.util.Map;

public interface Cnaps2CommSendService {
    void send(byte[] message, Map<String, String> info);
}
