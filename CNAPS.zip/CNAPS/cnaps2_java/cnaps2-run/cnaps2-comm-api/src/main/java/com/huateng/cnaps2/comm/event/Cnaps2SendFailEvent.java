package com.huateng.cnaps2.comm.event;

import com.huateng.cpg.event.ErrorEvent;

public class Cnaps2SendFailEvent extends ErrorEvent {
    private String id;
    private String pkgNo;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPkgNo() {
        return pkgNo;
    }

    public void setPkgNo(String pkgNo) {
        this.pkgNo = pkgNo;
    }
}
