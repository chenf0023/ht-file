package com.huateng.cnaps2.comm;

import com.huateng.cnaps2.comm.service.impl.Cnaps2CommExcpetionHandle;
import com.huateng.cnaps2.comm.service.impl.Cnaps2CommServiceImpl;
import org.springframework.context.annotation.Import;

@Import({Cnaps2CommServiceImpl.class, Cnaps2CommExcpetionHandle.class})
public class Cnaps2CommConfiguration {
}
