package com.huateng.cnaps2.bank.service;

import com.huateng.bank.message.BnkMsg;

public interface Hvps142BankService extends BankBaseService {
    void receive(BnkMsg bnkMsg);
}
