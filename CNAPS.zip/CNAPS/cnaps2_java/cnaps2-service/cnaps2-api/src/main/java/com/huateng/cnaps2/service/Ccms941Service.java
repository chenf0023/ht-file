package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_941_001_01;

public interface Ccms941Service extends IReceive<Ccms_941_001_01>{
}
