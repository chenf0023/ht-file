package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_725_001_02;

public interface Beps725_02Service extends IReceive<Beps_725_001_02>{
}
