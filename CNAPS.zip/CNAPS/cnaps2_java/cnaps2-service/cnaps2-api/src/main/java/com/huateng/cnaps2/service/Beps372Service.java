package com.huateng.cnaps2.service;


import com.huateng.cnaps2.message.Beps_372_001_01;

public interface Beps372Service extends IReceive<Beps_372_001_01>, ISend<Beps_372_001_01>{
}
