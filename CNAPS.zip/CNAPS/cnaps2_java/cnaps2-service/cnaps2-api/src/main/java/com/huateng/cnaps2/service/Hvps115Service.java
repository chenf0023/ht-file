package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_115_001_01;

public interface Hvps115Service extends IReceive<Hvps_115_001_01>, ISend<Hvps_115_001_01> {
}
