package com.huateng.cnaps2.service;

import com.huateng.bank.message.BnkMsg;
import com.huateng.cnaps2.message.Beps_414_001_01;

public interface Beps414Service extends IReceive<Beps_414_001_01>{
}
