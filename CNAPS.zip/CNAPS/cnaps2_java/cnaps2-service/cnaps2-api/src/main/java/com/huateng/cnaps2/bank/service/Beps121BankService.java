package com.huateng.cnaps2.bank.service;

import com.huateng.bank.message.BnkMsg;

public interface Beps121BankService extends BankBaseService {
    void receive(BnkMsg bnkMsg);
}
