package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_722_001_01;

public interface Beps722Service extends ISend<Beps_722_001_01> {
}
