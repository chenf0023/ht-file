package com.huateng.cnaps2.service;

import com.huateng.bank.message.BnkMsg;
import com.huateng.cnaps2.message.Saps_363_001_01;

public interface Saps363Service extends ISend<Saps_363_001_01> {
}
