package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Saps_614_001_01;

public interface Saps614Service extends ISend<Saps_614_001_01> {
}
