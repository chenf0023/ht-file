package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_710_001_01;

public interface Hvps710Service extends ISend<Hvps_710_001_01> {
}
