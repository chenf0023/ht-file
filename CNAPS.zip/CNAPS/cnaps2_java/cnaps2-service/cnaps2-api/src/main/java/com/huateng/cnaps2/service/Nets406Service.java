package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Nets_406_001_01;

public interface Nets406Service extends IReceive<Nets_406_001_01>{
}
