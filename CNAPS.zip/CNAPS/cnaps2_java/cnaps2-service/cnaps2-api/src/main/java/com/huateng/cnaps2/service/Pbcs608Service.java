package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Pbcs_608_001_01;

public interface Pbcs608Service extends IReceive<Pbcs_608_001_01>{
}