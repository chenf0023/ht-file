package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_125_001_01;

public interface Beps125Service extends IReceive<Beps_125_001_01>, ISend<Beps_125_001_01>{
}
