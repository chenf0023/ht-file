package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_992_001_01;

public interface Ccms992Service extends IReceive<Ccms_992_001_01>{
}
