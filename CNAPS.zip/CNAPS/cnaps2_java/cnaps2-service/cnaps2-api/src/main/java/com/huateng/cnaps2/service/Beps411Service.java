package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_411_001_01;

public interface Beps411Service extends IReceive<Beps_411_001_01>, ISend<Beps_411_001_01>{
}
