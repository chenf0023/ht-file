package com.huateng.cnaps2.service;

import com.huateng.bank.message.BnkMsg;

public interface ISend<T> {
    void send(BnkMsg message);
}
