package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_381_001_01;

public interface Beps381Service extends IReceive<Beps_381_001_01>, ISend<Beps_381_001_01> {
}
