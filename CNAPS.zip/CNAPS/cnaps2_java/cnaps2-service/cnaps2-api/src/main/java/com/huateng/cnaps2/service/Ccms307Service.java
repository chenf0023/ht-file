package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_307_001_02;

public interface Ccms307Service extends ISend<Ccms_307_001_02> {
}
