package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_142_001_01;

public interface Hvps142Service extends IReceive<Hvps_142_001_01>{
}
