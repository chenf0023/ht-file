package com.huateng.cnaps2.bank.service;

import com.huateng.bank.message.BnkMsg;

public interface Nets351BankService extends BankBaseService {
    void receive(BnkMsg bnkMsg);
}
