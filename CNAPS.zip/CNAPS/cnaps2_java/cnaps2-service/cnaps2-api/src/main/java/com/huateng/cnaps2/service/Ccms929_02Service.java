package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_929_001_02;

public interface Ccms929_02Service extends ISend<Ccms_929_001_02>{
}
