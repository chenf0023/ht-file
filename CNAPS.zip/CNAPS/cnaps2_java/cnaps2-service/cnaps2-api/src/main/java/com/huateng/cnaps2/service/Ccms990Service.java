package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_990_001_02;

public interface Ccms990Service extends IReceive<Ccms_990_001_02>,ISend<Ccms_990_001_02> {
}
