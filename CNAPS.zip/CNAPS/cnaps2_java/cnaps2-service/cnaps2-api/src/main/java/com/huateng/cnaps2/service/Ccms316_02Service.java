package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_316_001_02;

public interface Ccms316_02Service extends ISend<Ccms_316_001_02> {
}
