package com.huateng.cnaps2.service;


import com.huateng.cnaps2.message.Beps_352_001_01;


public interface Beps352Service extends IReceive<Beps_352_001_01>, ISend<Beps_352_001_01> {
}
