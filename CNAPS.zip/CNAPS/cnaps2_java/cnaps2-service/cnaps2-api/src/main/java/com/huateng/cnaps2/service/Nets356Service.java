package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Nets_356_001_01;

public interface Nets356Service extends IReceive<Nets_356_001_01>{
}
