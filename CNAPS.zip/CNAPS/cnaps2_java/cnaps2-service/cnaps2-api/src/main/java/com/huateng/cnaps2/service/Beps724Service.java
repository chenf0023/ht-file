package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_724_001_01;

public interface Beps724Service extends ISend<Beps_724_001_01> {
}
