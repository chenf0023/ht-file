package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Nets_354_001_01;

public interface Nets354Service extends ISend<Nets_354_001_01> {
}
