package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_314_001_01;

public interface Ccms314Service extends IReceive<Ccms_314_001_01>, ISend<Ccms_314_001_01>{
}
