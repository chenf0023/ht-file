package com.huateng.cnaps2.service.common;


public class Cnaps2Dict {


    /*目的系统*/
    static public class DEST_FLAG {
        public final static Dict CENTER = new Dict("1", "1-中心");
    }

    /*补发标志*/
    static public class RESND_FLAG {
        public final static Dict NORMAL = new Dict("0", "0-正常业务");
        public final static Dict RESND = new Dict("1", "1-对账补发业务");
    }

    /*记账标志*/
    static public class CBFLAG {
        public final static Dict YES = new Dict("1", "1-记账");
        public final static Dict NO = new Dict("0", "0-不记账");
    }

    /*跨境标志*/
    static public class ISCB {
        public final static Dict NO = new Dict("0", "0-非跨境业务");
        public final static Dict YES = new Dict("1", "1-跨境业务");
    }

    /*交易状态*/
    static public class COM_STATUS {
        public final static Dict NOTPROC = new Dict("00", "00-待处理/已接收");
        public final static Dict SENDING = new Dict("01", "01-正发送");
        public final static Dict SEND = new Dict("02", "02-已发送");
        public final static Dict OVERTIME = new Dict("03", "03-已超时");
        public final static Dict CANCEL = new Dict("04", "04-已取消");
        public final static Dict PROC = new Dict("05", "05-已处理");
        public final static Dict RTING = new Dict("06", "06-回执中");
        public final static Dict QUEUE = new Dict("07", "07-已排队");
        public final static Dict PACK = new Dict("08", "08-待打包");
        public final static Dict DSEND = new Dict("09", "09-待发送");
        public final static Dict PKG_STATUS_10 = new Dict("10", "10-待手工打包");
        public final static Dict REJECT = new Dict("20", "20-已拒绝");
        public final static Dict ABAND = new Dict("21", "21-已丢弃");
        public final static Dict SNDFAIL = new Dict("22", "22-发送失败");
        public final static Dict MODIFIED = new Dict("29", "29-已删除");
        public final static Dict LANDED = new Dict("30", "30-已落地");
        public final static Dict RETURNING = new Dict("32", "32-退回中");
        public final static Dict RETUREND = new Dict("33", "33-已退回");
    }

    /*业务状态*/
    static public class CP2_STATUS {
        public final static Dict ENTERED = new Dict("00", "00-已录入");
        public final static Dict REVIEWED = new Dict("01", "01-已复核");
        public final static Dict RECHECKREFUSED = new Dict("02", "02-复核拒绝");
        public final static Dict AUDITED = new Dict("03", "03-已审核");
        public final static Dict AUDITREFUSED = new Dict("04", "04-审核拒绝");
        public final static Dict SENT = new Dict("05", "05-已发送");
        public final static Dict RECEIVED = new Dict("06", "06-已接收");
        public final static Dict WAITFORAUDIT = new Dict("07","07-待审核");
        public final static Dict RETURNEDRECEIPT = new Dict("08", "08-已回执");
        public final static Dict CANCELED = new Dict("09", "09-已取消");
        public final static Dict HANDLED = new Dict("11", "11-已手工处理");
        public final static Dict FALL = new Dict("12", "12-已落地");
        public final static Dict TRANSMIT = new Dict("13", "13-已转发");
        public final static Dict CHARGE = new Dict("14", "14-已挂账");
        public final static Dict AUTHORIZED = new Dict("15", "15-已授权");
        public final static Dict AUTHORIZEDREFUSED = new Dict("16", "16-授权拒绝");
        public final static Dict CHECKFAILURE = new Dict("17", "17-检查失败");
        public final static Dict AGAINAUTHORIZATION = new Dict("18", "18-再发送修改待授权");
        public final static Dict RESENDAUTHORIZATION = new Dict("19", "19-再发送取消待授权");
        public final static Dict TODELETE = new Dict("20", "20-待删除");
        public final static Dict REFUNDED = new Dict("21", "21-已退汇");
        public final static Dict QUEUE = new Dict("30", "30-排队");
        public final static Dict CHANGE = new Dict("31", "31-已修改");
        public final static Dict RETURNING = new Dict("32", "32-退回中");
        public final static Dict RETUREND = new Dict("33", "33-已退回");
        public final static Dict ADDREFUSEREASON = new Dict("34","34-待补充退汇原因");

        public final static Dict HANDLEDENTERED = new Dict("40", "40-手工处理已录入");
        public final static Dict HANDLEDREVIEWED = new Dict("41", "41-手工处理已复核");
        public final static Dict FAULT = new Dict("42", "42-手工处理拒绝");
        public final static Dict CHECKSUCCESS = new Dict("43", "43-检查成功");
        public final static Dict MANUAL_CHECKSUCCESS = new Dict("44", "44-手工处理检查成功");
        public final static Dict ForceSEND = new Dict("45", "45-手工处理强制发送");
        public final static Dict TO_AUTHORIZED = new Dict("46", "46-已审核待授权");
        public final static Dict SEND_FAIL = new Dict("47", "47-发送T24失败");
        public final static Dict PROCESS_WAIT_SPECIFIED_DATE = new Dict("50", "50-待指定日期处理");
        public final static Dict PENDING = new Dict("51", "推迟处理");
        public final static Dict CS_QUEUE = new Dict("52", "52-行内排队");
        public final static Dict SEND_T24 = new Dict("53","53-已发送T24");
        public final static Dict T24_RETCODE_SUCCESS = new Dict("54","54-T24记账成功");
        public final static Dict T24_RETCODE_FAILED = new Dict("55","55-T24记账失败");
        public final static Dict T24_DELETED = new Dict("56","56-T24已删除");

    }

    /*业务状态*/
    static public class CP2_BATCH_STATUS {
        public final static Dict RETURNING = new Dict("32", "32-退回中");
        public final static Dict RETUREND = new Dict("33", "33-已退回");
    }

    static public class CS_RETCODE_STATUS{
        public final static Dict SUCCESS = new Dict("00","00-success");
        public final static Dict FAILED = new Dict("01","01-failed");
        public final static Dict DELETE = new Dict("09","09-delete");
    }
  static public class CP2_OPERATE_YTPE{
        public final static Dict REJECT = new Dict("01","01-拒绝");
        public final static Dict RESEND = new Dict("02","02-再发送");
  }


    /*人行业务状态*/
    static public class PROC_STATUS {
        public final static Dict TRANS = new Dict("PR00", "PR00- 已转发");
        public final static Dict TOBECONFIRM = new Dict("PR01", "PR01- 待认证");
        public final static Dict ACCOUNTPAID = new Dict("PR02", "PR02- 已付款");
        public final static Dict NETTING = new Dict("PR03", "PR03- 已轧差");
        public final static Dict LIQUIDATED = new Dict("PR04", "PR04- 已清算");
        public final static Dict SUCCESS = new Dict("PR05", "PR05- 已成功");
        public final static Dict PENDING = new Dict("PR06", "PR06- 待处理");
        public final static Dict PROCESSED = new Dict("PR07", "PR07- 已处理");
        public final static Dict CANCLE = new Dict("PR08", "PR08- 已撤销");
        public final static Dict REJECTED = new Dict("PR09", "PR09- 已拒绝");
        public final static Dict CONFIRMED = new Dict("PR10", "PR10- 已确认");
        public final static Dict QUEUEDUP = new Dict("PR11", "PR11- 轧差排队");
        public final static Dict CLEAREDQUEUE = new Dict("PR12", "PR12- 清算排队");
        public final static Dict PR13 = new Dict("PR13", "PR13- 清算异常，待重新清算");
        public final static Dict PAYMENTSTOPPED = new Dict("PR21", "PR21- 已止付");
        public final static Dict RUSHED = new Dict("PR22", "PR22- 已冲正");
        public final static Dict RETURNED = new Dict("PR23", "PR23- 已整包退回");
        public final static Dict NPCENDING = new Dict("PR24", "PR24- NPC未受理");
        public final static Dict PR25 = new Dict("PR25", "PR25- 已部分退回");
        public final static Dict OVERDATE = new Dict("PR32", "PR32- 已超期(逾期退回)");
        public final static Dict PR39 = new Dict("PR39", "PR39- 强制调减待处理");
        public final static Dict PR91 = new Dict("PR91", "PR91- 部分止付");
    }

    /*系统来源*/
    static public class SOURCE_TYPE {
        public final static Dict CPG = new Dict("1", "1-CPG柜面");
        public final static Dict PRC = new Dict("2", "2-中心");


    }

    static public class CS_SOURCE_TYPE{

        public final static Dict CPG = new Dict("1", "1-CPG");
        public final static Dict PRC = new Dict("2", "2-中心");
        public final static Dict T24 = new Dict("3", "3-T24");
        public final static Dict CSC = new Dict("4","4-CSC");

    }

    static public class BIZ_CTGY_HVPS_116 {
        public final static Dict ABC = new Dict("1", "02126-其他资金汇划");
    }

    static public class RET_ANSWER_RP00 {
        public final static Dict PR09 = new Dict("PR09", "大额单笔或小额整包退回");
        public final static Dict PR23 = new Dict("PR23", "已整包退回");
        public final static Dict PR25 = new Dict("PR25", "已部分退回");
    }

    /*来往账标志*/
    static public class DRCT_TYPE {
        public final static Dict SND = new Dict("1", "1-往账");
        public final static Dict RCV = new Dict("2", "2-来账");
    }

    /*系统编号*/
    static public class SYS_CODE {
        public final static Dict BEPS = new Dict("BEPS", "BEPS-小额批量支付系统");
        public final static Dict HVPS = new Dict("HVPS", "HVPS-大额实时支付系统");
        public final static Dict CCMS = new Dict("CCMS", "CCMS-公共控制与管理系统");
        public final static Dict SAPS = new Dict("SAPS", "SAPS-清算账户管理系统");
        public final static Dict NETS = new Dict("NETS", "NETS-轧差服务器系统");
        public final static Dict IBPS = new Dict("IBPS", "IBPS-网上支付跨行清算系统");
        public final static Dict PBCS = new Dict("PBCS", "PBCS-支付系统计费系统");
        public final static Dict PMIS = new Dict("PMIS", "PMIS-支付管理信息系统");
        public final static Dict NCIS = new Dict("NCIS", "NCIS-支票影像交换系统");
        public final static Dict ECDS = new Dict("ECDS", "ECDS-电子商业汇票系统");
        public final static Dict FXPS = new Dict("FXPS", "FXPS-境内外币支付系统");
        public final static Dict PMTS = new Dict("PMTS", "PMTS-支付报文传输平台");
        public final static Dict SYSM = new Dict("SYSM", "SYSM-内部系统");
    }

    /*退回类型*/
    static public class RETURN_TYPE {
        public final static Dict ALL = new Dict("RP00", "RP00-大额单笔或小额整包退回");
        public final static Dict PART = new Dict("RP01", "RP01-小额部分退回");
    }

    /*查询类型*/
    static public class INQ_TYPE_314 {
        public final static Dict WHOLE_PACKAGE = new Dict("QT00", "QT00-整包查询");
        public final static Dict SINGLE = new Dict("QT01", "QT01-单笔查询");
    }

    static public class INQ_TYPE_314_HVPS {
        public final static Dict NON_BANK_ACCEPTANCE = new Dict("QA00", "QA00-非银行承兑汇票");
        public final static Dict BANK_ACCEPTANCE = new Dict("QA01", "QA01-银行承兑汇票");
    }

    static public class INQ_TYPE_314_QUERY {
        public final static Dict WHOLE_PACKAGE = new Dict("QT00", "QT00-整包查询");
        public final static Dict SINGLE = new Dict("QT01", "QT01-单笔查询");
        public final static Dict NON_BANK_ACCEPTANCE = new Dict("QA00", "QA00-非银行承兑汇票");
        public final static Dict BANK_ACCEPTANCE = new Dict("QA01", "QA01-银行承兑汇票");
    }

    /*币种*/
    static public class CUR_TYPE {
        public final static Dict CNY = new Dict("CNY", "人民币");
        public final static Dict USD = new Dict("USD", "美元");
    }

    /*查复内容*/
    static public class REVIEW_CONTENT {
        public final static Dict CONTENT_CONSISTENT = new Dict("0", "查询汇票与我行承兑汇票记载内容一致");
        public final static Dict CONTENT_INCONSISTENCY = new Dict("1", "查询汇票与我行承兑汇票记载内容不一致");
    }

    static public class CB_TYPE {
        public final static Dict YES = new Dict("1", "跨境");
        public final static Dict NO = new Dict("0", "非跨境");
    }

    /*止付类型*/
    static public class STOPPAYMENTTYPECODE {
        public final static Dict ALL = new Dict("SP00", "SP00-整包止付");
        public final static Dict PART = new Dict("SP01", "SP01-部分止付");
    }

    /*止付应答状态*/
    static public class STOP_PAY_STATUS {
        public final static Dict ALL_YES = new Dict("SS00", "SS00-同意整包止付");
        public final static Dict PART_YES = new Dict("SS01", "SS01-同意部分止付");
        public final static Dict NO = new Dict("SS02", "SS01-拒绝");
    }

    /*止付应答状态*/
    static public class JOIN_SYSTEM {
        public final static Dict HVPS = new Dict("0", "大额系统");
        public final static Dict BEPS = new Dict("1", "小额系统");
        public final static Dict IBPS = new Dict("2", "网银系统");
    }

    /*止付应答状态*/
    static public class OPER_TYPE {
        public final static Dict ADD = new Dict("CC00", "CC00-新增");
        public final static Dict MODIFY = new Dict("CC01", "CC01-修改");
        public final static Dict DELETE = new Dict("CC02", "CC02-删除");
    }

    /*排队指令类型*/
    static public class Q_INSTR_TYPE {
        public final static Dict QI05 = new Dict("QI05", "QI05-单边业务");
        public final static Dict QI06 = new Dict("QI06", "QI06-即时转账、大额支付（紧急）");
        public final static Dict QI07 = new Dict("QI07", "QI07-即时转账、大额支付（普通）");
        public final static Dict QI00 = new Dict("QI00", "QI00-冲正");
        public final static Dict QI01 = new Dict("QI01", "QI01-即时转账、大额支付（特急）");
        public final static Dict QI02 = new Dict("QI02", "QI02-透支计息、收费");
        public final static Dict QI03 = new Dict("QI03", "QI03-同城轧差净额");
        public final static Dict QI04 = new Dict("QI04", "QI04-小额轧差净额");
    }

    /*排队指令类型*/
    static public class MANAGE_CODE {
        public final static Dict M_ADD = new Dict("MC00", "MC00-注册");
        public final static Dict M_DEL = new Dict("MC01", "MC01-撤销");
        public final static Dict M_DEL_MUST = new Dict("MC02", "强制撤销");
        public final static Dict M_LOAD = new Dict("MC03", "MC03-下载");
    }

    static public class PARTICIPANTMAIN_CODE {
        public final static Dict M_ADD = new Dict("A", "A-新增");
        public final static Dict M_MODIFY = new Dict("M", "M-修改");
        public final static Dict M_DEL = new Dict("D", "D-删除");
    }

    //邮件信息配置管理-是否生效
    static public class MAIL_CONFIGURATION_CODE {
        public final static Dict YES = new Dict("10", "生效");
        public final static Dict NO = new Dict("00", "失效");

    }

    //邮件信息配置管理-业务事件号
    static public class MAIL_CONFIGURATION_EVENTKEY {
        public final static Dict EVENT_00 = new Dict("E001", "E001-往账STP检查失败");
        public final static Dict EVENT_01 = new Dict("E002", "E002-来账STP检查失败");
        //		public final static Dict EVENT_02=  new Dict("E002","E002-退汇检查失败");
        public final static Dict EVENT_02 = new Dict("E003", "E003-CPG和PBOC对账结果");
        public final static Dict EVENT_03 = new Dict("E004", "E004-CPG待办事项处理");

    }

    static public class MAIL_CONFIGURATION_TYPE {
        public final static Dict M_ADD = new Dict("01", "01-新增");
        public final static Dict M_MODIFY = new Dict("02", "02-修改");
        public final static Dict M_DEL = new Dict("03", "03-删除");

    }

    static public class BIZRT_STATUS_117 {
        public final static Dict M_01 = new Dict("PR10", "PR10-已确认");
        public final static Dict M_02 = new Dict("PR09", "PR09-已拒绝");

    }

    //大额延迟结算划回录入-业务类型
    static public class HIGHVALUE_DELAYED_BIZTYPE {
        public final static Dict B_TYPE = new Dict("A200", "A200-行间资金汇划");
    }

    //大额延迟结算划回录入-业务种类
    static public class HIGHVALUE_DELAYED_BIZCTGY {
        public final static Dict B_CTGY = new Dict("02126", "02126-其他资金汇划");
    }

    /*异常状态*/
    static public class EXCEPTION_STATUS {
        public final static Dict EXCEPTION_STATUS_00 = new Dict("00", "00-未处理");
        public final static Dict EXCEPTION_STATUS_01 = new Dict("01", "01-处理中");
        public final static Dict EXCEPTION_STATUS_02 = new Dict("02", "02-已处理");
        public final static Dict EXCEPTION_STATUS_04 = new Dict("04", "04-部分待处理");
        public final static Dict EXCEPTION_STATUS_05 = new Dict("05", "05-部分已处理");
    }

    /*异常类型*/
    static public class EXCEPTION_TYPE {
        public final static Dict EXCEPTION_TYPE_00 = new Dict("00", "00-往账报文加签失败");
        public final static Dict EXCEPTION_TYPE_01 = new Dict("01", "01-往账报文发送超时");
        public final static Dict EXCEPTION_TYPE_02 = new Dict("02", "02-往账报文行内发送失败");
        public final static Dict EXCEPTION_TYPE_03 = new Dict("03", "03-往账报文丢弃");
        public final static Dict EXCEPTION_TYPE_04 = new Dict("04", "04-往账报文拒绝");
        public final static Dict EXCEPTION_TYPE_05 = new Dict("05", "05-往账被核押错");
        public final static Dict EXCEPTION_TYPE_06 = new Dict("06", "06-往账stp检查异常");
        public final static Dict EXCEPTION_TYPE_07 = new Dict("07", "07-往账发送service异常");
        public final static Dict EXCEPTION_TYPE_10 = new Dict("10", "10-来账报文核签失败");
        public final static Dict EXCEPTION_TYPE_11 = new Dict("11", "11-来账报文解析失败");
        public final static Dict EXCEPTION_TYPE_12 = new Dict("12", "12-来账报文其它错");
    }
    static public class POSITION_OPTYPE {
        public final static Dict POSITION_OPTYPE_01 = new Dict("01", "01-已录入");
        public final static Dict POSITION_OPTYPE_02 = new Dict("02", "02-已审核");
        public final static Dict POSITION_OPTYPE_03 = new Dict("03", "03-已拒绝");
    }
    /* 异常操作类型 */
    static public class EXCEPTION_OPTYPE {
        public final static Dict EXCEPTION_OPTYPE_00 = new Dict("00", "00-转手工处理");
        public final static Dict EXCEPTION_OPTYPE_01 = new Dict("01", "01-拒绝");
        public final static Dict EXCEPTION_OPTYPE_02 = new Dict("02", "02-重新发送");

 /*       public final static Dict EXCEPTION_OPTYPE_00 = new Dict("00", "00-修改");
        public final static Dict EXCEPTION_OPTYPE_02 = new Dict("02", "02-再发送");
        public final static Dict EXCEPTION_OPTYPE_03 = new Dict("03", "03-取消发送");
        public final static Dict EXCEPTION_OPTYPE_10 = new Dict("10", "10-重新核签");
        public final static Dict EXCEPTION_OPTYPE_11 = new Dict("11", "11-上次数字证书核签");
        public final static Dict EXCEPTION_OPTYPE_12 = new Dict("12", "12-强制核签");
        public final static Dict EXCEPTION_OPTYPE_13 = new Dict("13", "13-重新解析");
        public final static Dict EXCEPTION_OPTYPE_14 = new Dict("14", "14-落地");*/
    }

    /* 系统参数 */
    static public class TXN_PARA {
        public final static Dict TXN_PARA_EXCPTIME = new Dict("0201", "异常处理超时");
        public final static Dict TXN_PARA_HVPSAUTRECON = new Dict("0161", "大额业务自动对账开关");
        public final static Dict TXN_PARA_BEPSAUTRECON = new Dict("0162", "小额业务自动对账开关");
        public final static Dict TXN_PARA_RESND = new Dict("0400", "往帐疑似重账");
        public final static Dict TXN_PARA_KEYWD = new Dict("0401", "关键字");
        public final static Dict TXN_PARA_BLIST = new Dict("0402", "黑名单交易");
        public final static Dict TXN_PARA_MOAMT = new Dict("0403", "往帐大金额");
        public final static Dict TXN_PARA_ACTNO = new Dict("0404", "账户信息错误");
        public final static Dict TXN_PARA_RCVCK = new Dict("0405", "往帐接收行号检查");
        public final static Dict TXN_PARA_RCVCA = new Dict("0405", "来账被退汇");
        public final static Dict TXN_PARA_NONSTPAMT = new Dict("8507", "non_stp金额");
    }

    /* 临时表参数管理*/
    static public class CP_2BATCH_TYPE {
        public final static Dict PENDINGREVIEW = new Dict("0", "0-待审核");
        public final static Dict REVIEWED = new Dict("1", "1-已审核");
        public final static Dict REJECTED = new Dict("2", "2-已拒绝");
    }

    static public class CS_CUST_TXN_STATUS {
        public final static Dict PENDING = new Dict("00", "00-待处理");
        public final static Dict SUCCESS = new Dict("01", "01-处理成功");
        public final static Dict FAILED = new Dict("02", "02-处理失败");
        public final static Dict CANCEL = new Dict("03", "03-已取消");
        public final static Dict DELETE = new Dict("04", "04-T24已删除");
        public final static Dict IMPORTED =  new Dict("38","38-行内已导入");
    }

    static public class CS_CUST_TXN_NSTP_TYPE {
        public final static Dict PASS = new Dict("00", "00-来/往账 STP检查通过");
        public final static Dict DEBIT_BASE_CHECK_FAILED = new Dict("01", "01-往账基础要素检查失败");
        public final static Dict DEBIT_REACCOUNT_CHECK_FAILED = new Dict("02", "02-往账疑似重账检查失败");
        public final static Dict DEBIT_KEYWOARD_CHECK_FAILED = new Dict("03", "03-往账关键字检查失败");
        public final static Dict DEBIT_BLACKLIST_CHECK_FAILED = new Dict("04", "04-往账黑名单检查失败");
        public final static Dict DEBIT_PUBLIC_TO_PRIVATE_CHECK_FAILED = new Dict("05", "05-往账公转私检查失败");
        public final static Dict FUTURE_DATE = new Dict("06", "06-Future Date 交易");
        public final static Dict IN_LINE_QUEUE = new Dict("07", "07-行内排队");
        public final static Dict INCOMING_KEYWORD_CHECK_FAILED = new Dict("08", "08-来账关键字检查失败");
        public final static Dict INCOMING_BLACKLIST_CHECK_FAILED = new Dict("09", "09-来账黑名单检查失败");
        public final static Dict INCOMING_REFUND_EXCHANGE = new Dict("10", "10-来账退汇");
        public final static Dict RNA_ACCOUNT = new Dict("11", "11-NRA账户");
        public final static Dict INSTANT_TRANSFER_TRANSACTION_LOAN_FLAG_CHECK_FAILED = new Dict("12", "12-即时转账交易借贷标志检查失败");
        public final static Dict SMALL_TERM_DEBIT_CONTRACT_CHECK_FAILED = new Dict("13", "13-小额定期借记合同检查失败");
        public final static Dict REQUIRED_FIELD_VALIDATION_FAILED= new Dict("97", "97必选字段校验失败");

    }


    // non-STP类型
    public static class NSTP_TYPE {
        public static final Dict SUCCESS        = new Dict("00", "00-来/往账 STP检查通过");
        // public static final Dict ERR_01         = new Dict("01", "01-往账基础要素检查失败");
        public static final Dict ERR_02         = new Dict("11", "11-往账重账检查失败");
        public static final Dict ERR_03         = new Dict("12", "12-往账关键字检查失败");
        public static final Dict ERR_04         = new Dict("14", "14-往账黑名单检查失败");
        public static final Dict ERR_05         = new Dict("15", "15-往账公转私检查失败");
        // public static final Dict ERR_06         = new Dict("06", "06-Future Date 交易");
        public static final Dict ERR_07         = new Dict("16", "16-往账头寸检查失败");
        public static final Dict ERR_08         = new Dict("21", "21-来账关键字检查失败");
        public static final Dict ERR_09         = new Dict("22", "22-来账黑名单检查失败");
        public static final Dict ERR_10         = new Dict("23", "23-来账退汇业务检查失败");
        public static final Dict ERR_11         = new Dict("24", "24-来账NRA检查失败");
        // public static final Dict ERR_12         = new Dict("12", "12-即时转账交易借贷标志检查失败");
        public static final Dict ERR_13         = new Dict("25", "25-来账小额定期借记协议检查失败");
        public static final Dict ERR_14         = new Dict("13", "13-往账大金额检查失败");
        public final static Dict REQUIRED_FIELD_VALIDATION_FAILED= new Dict("97", "97-必验性校验错误");

        public static final Dict ILLEGAL      = new Dict("98", "98-参数不合法");
        public static final Dict EXCEPTION      = new Dict("99", "99-未知校验异常");
    }

    public static class NON_STP_TYPE {
        public static final Dict ERR_02         = new Dict("11","11-往账重账校验");
        public static final Dict ERR_03         = new Dict("12","12-往账关键字校验");
        public static final Dict ERR_04         = new Dict("13","13-往账大金额校验");
        public static final Dict ERR_05         = new Dict("14","14-往账黑名单校验");
        public static final Dict ERR_07         = new Dict("15","15-往账公转私");
        public static final Dict ERR_08         = new Dict("16","16-往账头寸检查");
        public static final Dict ERR_09         = new Dict("21","21-来账关键字校验");
        public static final Dict ERR_10         = new Dict("22","22-来账黑名单校验");
        public static final Dict ERR_11         = new Dict("23","23-来账退汇业务检查");
        public static final Dict ERR_13         = new Dict("24","24-来账NRA检查");
        public static final Dict ERR_14         = new Dict("25","25-来账小额定期借记协议检查");
    }


    /*业务状态*/
    static public class CP2_TXN_CUST_STATUS {
        public final static Dict CP2_CUST_STATUS1 = new Dict("CUST_STATUS1", "客户化状态1");
        public final static Dict CP2_CUST_STATUS2 = new Dict("CUST_STATUS2", "客户化状态2");
        public final static Dict CP2_CUST_STATUS3 = new Dict("CUST_STATUS3", "客户化状态3");
    }

    /*业务状态*/
    static public class CP2_PKG_TYPE {
        public final static Dict CCMS_318_001_01 = new Dict("ccms.318.001.01", "业务退回请求");
        public final static Dict CCMS_319_001_01 = new Dict("ccms.319.001.01", "业务退回应答");
    }


    static public class NstpOptype {
        public final static Dict REFUND = new Dict("00", "退汇");
        public final static Dict FORCESEND = new Dict("02", "强制发送");
        public final static Dict INWARD_REVISE = new Dict("03", "来账修改");
        public final static Dict OUTWARD_REVISE = new Dict("04", "往账修改");
        public final static Dict FAULT = new Dict("06", "拒绝");

        public final static Dict FORCESEND_98 = new Dict("07", "98强制发送校验STP");

        public final static Dict OUTWARD_REVISE_98 = new Dict("08", "98往账修改校验STP");

        public final static Dict UNDETERMINED = new Dict("09", "推迟处理");
    }

    //STP操作类型          01-新增     03-删除
    static public class Stp_Optype{
        public final static Dict ADD    =new Dict("1","新增");
        public final static Dict DELETE =new Dict("3","删除");
    }
    //STP审核状态          01-待审核	02-通过	03拒绝
   static public class Stp_Status{
        public final static Dict PENDINGREVIEW = new Dict("00", "0-待审核");
        public final static Dict REVIEWED = new Dict("01", "1-已审核");
        public final static Dict REJECTED = new Dict("02", "2-已拒绝");
    }

    static public class EmailSendType{
        public final static Dict SUCCESSED = new Dict("01", "01-成功");
        public final static Dict FAILED = new Dict("02", "02-失败");
    }

    /**
     * 队列操作类型
     */
    static public class SYS_TYPE_QUEUE{
        public final static Dict TO_TOP = new Dict("01", "01-移至队首");
        public final static Dict TO_LAST = new Dict("02", "02-移至队尾");
        public final static Dict SEND_NOW = new Dict("03", "03-立即发送");
    }
}
