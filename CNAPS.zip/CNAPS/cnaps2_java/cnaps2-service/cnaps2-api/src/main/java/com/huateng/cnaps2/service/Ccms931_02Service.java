package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_931_001_02;

public interface Ccms931_02Service extends IReceive<Ccms_931_001_02>{
}
