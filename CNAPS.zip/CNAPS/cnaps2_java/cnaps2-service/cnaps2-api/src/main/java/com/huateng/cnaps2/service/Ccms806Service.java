package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_806_001_02;

public interface Ccms806Service extends IReceive<Ccms_806_001_02>{
}
