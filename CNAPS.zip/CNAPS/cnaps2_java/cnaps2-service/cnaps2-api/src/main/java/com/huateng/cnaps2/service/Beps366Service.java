package com.huateng.cnaps2.service;


import com.huateng.cnaps2.message.Beps_366_001_01;

public interface Beps366Service extends IReceive<Beps_366_001_01>{
}
