package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_117_001_01;

public interface Hvps117Service extends ISend<Hvps_117_001_01> {
}
