package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Saps_615_001_01;

public interface Saps615Service extends IReceive<Saps_615_001_01>{
}
