package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_124_001_01;

public interface Beps124Service extends IReceive<Beps_124_001_01>, ISend<Beps_124_001_01>{
}
