package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_131_001_02;

public interface Beps131_02Service extends IReceive<Beps_131_001_02>, ISend<Beps_131_001_02>{
}
