package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_724_001_02;

public interface Beps724_02Service extends ISend<Beps_724_001_02> {
}
