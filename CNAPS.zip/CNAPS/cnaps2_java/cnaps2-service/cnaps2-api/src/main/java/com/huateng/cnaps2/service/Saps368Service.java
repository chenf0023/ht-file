package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Saps_368_001_01;

public interface Saps368Service extends ISend<Saps_368_001_01> {
}
