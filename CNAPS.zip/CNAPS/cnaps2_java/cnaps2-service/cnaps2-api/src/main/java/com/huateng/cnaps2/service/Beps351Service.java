package com.huateng.cnaps2.service;


import com.huateng.cnaps2.message.Beps_351_001_01;


public interface Beps351Service extends IReceive<Beps_351_001_01>, ISend<Beps_351_001_01> {
}
