package com.huateng.cnaps2.batch.dal.mapper.ext;

import com.huateng.cs.busi.dal.model.CsTxnQueue;


public interface CsTxnQueueBepsBatchExtMapper {

    /**
     * 查询队首节点
     */
    CsTxnQueue selectTop();

    /**
     * 查询正在出队节点
     * @return
     */
    CsTxnQueue selectDequeueIng();

    int updateByPrimaryKey(CsTxnQueue record);

}