package com.huateng.cnaps2.batch.dal.model.ext;

import lombok.Data;

@Data
public class CpgDateModel {
    public String count1;
    public String count2;
    public String count3;
    public String count4;
    public String count5;
    public String count6;
    public String count7;
    public String count8;
    public String count9;
    public String count10;
    public String count11;
    public String count12;
}
