package com.huateng.cnaps2.batch.dal.model.ext;

import lombok.Data;

/**
 * Created with Intellij IDEA
 *
 * @Auther: linchengjie
 * @Data: 2022-01-19 10:01
 * @Description:
 */
@Data
public class ExtCpgDateOrg {
    private String vdate;
    private String brno;
}
