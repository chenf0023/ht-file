package com.huateng.cnaps2.batch.dal.model.ext;

import lombok.Data;

@Data
public class Cp2TxnToCsv {
    private String coreId;
    private String upstreamId;
    private String msgId;
    private String btId;
    private String sysCode;
    private String brno;
    private String workDate;
    private String txnDate;
    private String vdate;
    private String drct;
    private String source;
    private String pkgNo;
    private String ProcStatus;
    private String sndStBrno;
    private String RcvStBrno;
    private String payerName;
    private String payerAddr;
    private String payerActno;
    private String payerAccBrno;
    private String payerAccBrName;
    private String payerBrno;
    private String payeeBrno;
    private String payeeName;
    private String payeeAddr;
    private String payeeActno;
    private String payeeAccBrName;
    private String payeeAccBrno;
    private String curcd;
    private String amount;
    private String bizCtgyCode;
    private String bizTypeCode;
    private String chkDate;
    private String chkRound;
    private String clrDate;
    private String oriId;
    private String oriPkgId;
    private String oriSender;
    private String procCode;
    private String procInfo;



}
