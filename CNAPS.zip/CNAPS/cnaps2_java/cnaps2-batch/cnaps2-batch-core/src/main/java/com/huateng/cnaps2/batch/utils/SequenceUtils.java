package com.huateng.cnaps2.batch.utils;

import com.huateng.cnaps2.batch.task.TaskSaps366;
import com.huateng.cnaps2.batch.utils.model.CpgSequence;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 序列号服务
 * */

@Service
public class SequenceUtils {
    private static final Logger logger = LoggerFactory.getLogger(SequenceUtils.class);

    protected final Object lock = new Object();
    protected Map<String, Sequence> map = new HashMap<>();
    protected static final long MIN_INCREMENT = 100;

    @Value("${spring.datasource.url}")
    protected String url;

    @Value("${spring.datasource.username}")
    protected String userName;

    @Value("${spring.datasource.password}")
    protected String password;

    @Value("CPG_SEQUENCE")
    protected String tableName;


    public static AtomicLong ctomicLong=new AtomicLong(0);

    /**
    * 生成自增ID    8位  如果满了从1开始
    * */
    public static String genIncreId(){
        long l=ctomicLong.addAndGet(1);//步长1
        if(l>99999999){
            ctomicLong=new AtomicLong(0);
            l=ctomicLong.addAndGet(1);
        }
        return String.format("%08d",l);
    }
    /**
    * 日期时间+自增序号
    * */
    public static String getId(){
        return DateUtils.currentDateTimeFormat("yyyyMMddHHmmss")+genIncreId();
    }

    public  String getIdByDb(String sysId){
        return sysId+DateUtils.currentDateTimeFormat("yyyyMMdd")+gen("cnaps2_id_seq");
    }

    public String gen(String bussType) {
        return getSequence(bussType).next();
    }

    protected Sequence getSequence(String bussType) {
        Sequence sequence = map.get(bussType);
        if ( null == sequence ) {
            synchronized ( lock ) {
                sequence = map.get(bussType);
                if ( null == sequence ) {
                    sequence = new Sequence(bussType);
                    map.put(bussType, sequence);
                }
            }
        }

        return sequence;
    }

    protected Connection getConnect() throws SQLException {
        logger.debug("\nurl:{}\nusername:{}\npassword:{}",url, userName, password);
        return DriverManager.getConnection(url, userName, password);
    }


    protected class Sequence {
        protected final Object lock = new Object();
        protected AtomicLong current;
        protected long max;
        protected String format;
        protected String type;

        public Sequence(String type) {
            this.current = new AtomicLong(0);
            this.max = 0;
            this.type = type;
        }

        public String next() {
            long next;
            while ( true ) {
                if ( current.get() >= max ) {
                    update();
                }

                next = current.getAndIncrement();
                if ( next >= max ) {
                    update();
                } else {
                    break;
                }
            }

            return String.format(format, next);
        }

        protected void update() {
            synchronized ( lock ) {
                if ( current.get() < max ) {
                    return;
                }

                max = -1;
                Connection connection = null;
                try {
                    connection = getConnect();
                    connection.setAutoCommit(false);
                    CpgSequence tipsSequence = selectByPrimaryKey(connection, type);
                    if ( null == tipsSequence ) {
                        throw new RuntimeException(type + ": sequence not defined");
                    }

                    long temp = tipsSequence.getCurrentValue();
                    if ( temp >= tipsSequence.getMaxValue() ) {
                        temp = tipsSequence.getMinValue();
                    }

                    if ( tipsSequence.getAutoIncrementValue() < MIN_INCREMENT ) {
                        tipsSequence.setAutoIncrementValue(MIN_INCREMENT);
                    }

                    long next = temp + tipsSequence.getAutoIncrementValue();
                    if ( next > tipsSequence.getMaxValue() ) {
                        next = tipsSequence.getMaxValue();
                    }
                    tipsSequence.setCurrentValue(next);

                    updateByPrimaryKey(connection, tipsSequence);
                    format = "%0"+tipsSequence.getLengthLimit()+"d";

                    current.set(temp);
                    max = next;

                    connection.commit();
                } catch (Exception e) {
                    if ( null != connection ) {
                        try {
                            connection.rollback();
                        } catch (SQLException e2) {
                            e2.printStackTrace();
                        }
                    }
                    throw new RuntimeException(e);
                } finally {
                    if ( null != connection ) {
                        try {
                            connection.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }

    protected CpgSequence selectByPrimaryKey(Connection connection, String type) throws SQLException {
        PreparedStatement prepareStatement = connection.prepareStatement(
                "select ID, MIN_VALUE, CURRENT_VALUE, MAX_VALUE, AUTO_INCREMENT_VALUE, LENGTH_LIMIT from "+ tableName +" where ID = ? for update");
        prepareStatement.setString(1, type);
        ResultSet resultSet = prepareStatement.executeQuery();
        CpgSequence cpgSequence = new CpgSequence();
        if ( resultSet.next() ) {
            cpgSequence.setId(resultSet.getString(1));
            cpgSequence.setMinValue(resultSet.getLong(2));
            cpgSequence.setCurrentValue(resultSet.getLong(3));
            cpgSequence.setMaxValue(resultSet.getLong(4));
            cpgSequence.setAutoIncrementValue(resultSet.getLong(5));
            cpgSequence.setLengthLimit(resultSet.getLong(6));
        }

        return cpgSequence;
    }

    protected int updateByPrimaryKey(Connection connection, CpgSequence cpgSequence) throws SQLException {
        PreparedStatement prepareStatement = connection.prepareStatement(
                "update " + tableName + " set MIN_VALUE = ?,  CURRENT_VALUE = ?,  MAX_VALUE = ?,  AUTO_INCREMENT_VALUE = ?,  LENGTH_LIMIT = ? where ID = ?");
        prepareStatement.setLong(1, cpgSequence.getMinValue());
        prepareStatement.setLong(2, cpgSequence.getCurrentValue());
        prepareStatement.setLong(3, cpgSequence.getMaxValue());
        prepareStatement.setLong(4, cpgSequence.getAutoIncrementValue());
        prepareStatement.setLong(5, cpgSequence.getLengthLimit());
        prepareStatement.setString(6, cpgSequence.getId());
        return prepareStatement.executeUpdate();
    }
}
