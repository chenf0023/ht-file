package com.huateng.cnaps2.batch.utils;

import com.huateng.cs.busi.api.model.CheckRequest;

public interface STPCheckProc {
    void proc(CheckRequest... params);
}
