package com.huateng.cnaps2.batch.task;

import com.huateng.cnaps2.batch.dal.mapper.ext.ExtExceptionHandleMapper;
import com.huateng.cnaps2.batch.dal.model.ext.*;
import com.huateng.cnaps2.batch.dynamicSchedule.BaseTask;
import com.huateng.cnaps2.batch.utils.DateUtils;
import com.huateng.cnaps2.batch.utils.SequenceUtils;
import com.huateng.cpg.mapper.CpgBaseDataMapper;
import com.huateng.cpg.mapper.CpgExceptionInfMapper;
import com.huateng.cpg.model.*;
import com.huateng.mybatis.ext.plugin.Lock;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.jdbc.Null;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/*
* 定时处理异常记录
* */
@Service
public class TaskExceptionHandler extends BaseTask {
    private static final Logger logger = LoggerFactory.getLogger(TaskExceptionHandler.class);
    @Resource
    private CpgBaseDataMapper  cpgBaseDataMapper;
    @Resource
    private CpgExceptionInfMapper cpgExceptionInfMapper;
    @Resource
    private ExtExceptionHandleMapper extExceptionHandleMapper;
    @Resource
    private SequenceUtils sequenceUtils;


    @Override
    public void init() {
        super.init();
        super.setScheduleId("3");
    }

    @Override
    public void process() {
        logger.debug("####################[定时处理异常记录]####################");
        super.setProcess();

        if(0!=this.exceptionLock()){
            super.setFail("异常处理锁加锁失败");
            return;
        }
        try {
            //大额异常处理

            this.getHvpsTxn();
            //小额异常处理
            this.getBepsTxn();
            //异常恢复
            this.resumeExcp();
            //可疑处理
            this.getFaultTxn();
            this.getMissTxn();


        }catch (Exception e){
            e.printStackTrace();
        }
        // ExceptionUnLock 解锁
        if(0!=this.exceptionUnLock()){
            super.setFail("异常处理锁解锁失败");
            return;
        }
        super.setSuccess();
        return;
    }
    /**
     * 大额异常处理
     * */
    public void getHvpsTxn(){
        //获取基础数据
        logger.info("#####################大额异常处理#####################");
        List<ExtHvpsExcpTxn> hvpsExcpTxns=extExceptionHandleMapper.queryHvpsExcp();
        logger.info("异常交易:{}条",hvpsExcpTxns.size());
        //原交易是否已经录入异常表
        for(ExtHvpsExcpTxn oriHvpsTxn:hvpsExcpTxns) {
            String excpType = null;
            //2-来账
            if ("2".equals(oriHvpsTxn.getDrct())) {
                excpType = "10";
                logger.debug("来账异常,异常类型:{},txnId:{},pkgNo:{}", excpType, oriHvpsTxn.getId(), oriHvpsTxn.getPkgNo());
            }
            //1-往账
            if ("1".equals(oriHvpsTxn.getDrct())) {

                if ("01".equals(oriHvpsTxn.getStatus())) {//正发送
                    logger.debug("", oriHvpsTxn.getSndTime());
                    logger.debug("交易处理中，计算是否超时,发送时间:{}", oriHvpsTxn.getSndTime());
                    String currentDT = DateUtils.currentDateTimeFormat("yyyyMMddHHmmss");
                    if (StringUtils.isNoneBlank(currentDT)) {
                        logger.debug("该交易发送时间为空，则认为该交易超时");
                        excpType = "01";
                    } else {
                        logger.debug("当前时间:{}", currentDT);
                        long l = DateUtils.dateDiff(oriHvpsTxn.getSndTime(), currentDT, "yyyyMMddHHmmss", "s");
                        logger.debug("时间差:{}", l);
                        //  当前时间-来账时间>超时时间
                        if (l > 300) {
                            //如果超时  设置  异常类型，插表
                            excpType = "01";
                        } else {
                            //如果没超时，跳过
                            continue;
                        }
                    }
                } else if ("22".equals(oriHvpsTxn.getStatus())) {
                    excpType = "02";
                } else if ("21".equals(oriHvpsTxn.getStatus())) {
                    excpType = "03";
                } else if ("20".equals(oriHvpsTxn.getStatus())) {
                    /*往账核押错*/
                    if ("O4006".equals(oriHvpsTxn.getAProcCode())) {
                        excpType = "05";
                    } else {
                        excpType = "04";
                    }
                } else {
                    excpType = "04";
                }
                logger.debug("往账异常,异常类型:{},txnId:{},pkgNo:{}", excpType, oriHvpsTxn.getId(), oriHvpsTxn.getPkgNo());
            }

            int count = extExceptionHandleMapper.queryCpgExceptionInf(oriHvpsTxn.getId());
            logger.info("异常表中txnid:" + oriHvpsTxn.getId() + ",有" + count + "条记录");
            //如果异常表中无异常记录，或者大于1条记录(做过处理后，又有异常)，选择插入这条异常
            if (count == 0 || count > 1) {
                CpgExceptionInf exceptionInf = new CpgExceptionInf();
                exceptionInf.setId(sequenceUtils.getIdByDb("SYSM"));
                exceptionInf.setTxnId(oriHvpsTxn.getId());
                exceptionInf.setBrno(oriHvpsTxn.getBrno());
                exceptionInf.setCpgdate(oriHvpsTxn.getVdate());
                exceptionInf.setSysCode("HVPS");
                exceptionInf.setPkgNo(oriHvpsTxn.getPkgNo());
                exceptionInf.setWorkdate(oriHvpsTxn.getWorkdate());
                exceptionInf.setMsgId(oriHvpsTxn.getMsgId());
                exceptionInf.setOrgSender(oriHvpsTxn.getOrgSender());
                exceptionInf.setOrgSenderDate(oriHvpsTxn.getOrgSenderDate());
                exceptionInf.setDrct(oriHvpsTxn.getDrct());
                exceptionInf.setSndTime(oriHvpsTxn.getSndTime());
                exceptionInf.setRcvTime(oriHvpsTxn.getRcvTime());
                exceptionInf.setAmount(oriHvpsTxn.getAmount());
                exceptionInf.setExceptionType(excpType);
                exceptionInf.setStatus("00");
                if (oriHvpsTxn.getAProcCode() != null) {
                    exceptionInf.setProcCode(oriHvpsTxn.getAProcCode());
                }
                if (oriHvpsTxn.getRejectInfo() != null) {
                    exceptionInf.setRejectInfo(oriHvpsTxn.getRejectInfo());
                }
                int iRet = cpgExceptionInfMapper.insertSelective(exceptionInf);
                if (iRet != 1) {
                    logger.error("入库失败");
                }//00-已接受，01-处理中，02-已处理
            } else if (count == 1) {
                CpgExceptionInf cpgExceptionInf = extExceptionHandleMapper.selectByTxnid(oriHvpsTxn.getId(), Lock.forUpdate);
                cpgExceptionInf.setExceptionType(excpType);
                cpgExceptionInf.setStatus("00");
                if (oriHvpsTxn.getAProcCode() != null) {
                    cpgExceptionInf.setProcCode(oriHvpsTxn.getAProcCode());
                }
                if (oriHvpsTxn.getRejectInfo() != null) {
                    cpgExceptionInf.setRejectInfo(oriHvpsTxn.getRejectInfo());
                }
                cpgExceptionInfMapper.updateByPrimaryKey(cpgExceptionInf);

            }
        }
    }
    /**
     * 小额异常处理
     * */
    public void getBepsTxn(){
        //获取基础数据
        logger.info("#####################小额异常处理#####################");
        List<ExtBepsExcpTxn> bepsExcpTxns=extExceptionHandleMapper.queryBepsExcp();
        logger.info("异常交易:{}条",bepsExcpTxns.size());

        //原交易是否已经录入异常表
        for(ExtBepsExcpTxn oriBepsTxn:bepsExcpTxns){
            logger.debug("异常交易:{}",oriBepsTxn);
            String pkgNo=oriBepsTxn.getPkgNo();
            //报文编号不能为空
            if(!StringUtils.isNoneBlank(pkgNo)){
                logger.debug("报文编号为空，跳过处理");
                continue;
            }
            String pkgId=pkgNo.substring(5,8);
            String pkgName=getDataDesc("PKG_NO",pkgId);
            List<ExtCpgDateOrg> extCpgDateOrgs=extExceptionHandleMapper.queryCpgDateAndBrno(oriBepsTxn.getId(),pkgId);
            logger.debug("extCpgDateOrgs={}",extCpgDateOrgs);

//            CpgExceptionInfExample example=new CpgExceptionInfExample();
//            CpgExceptionInfExample.Criteria criteria= example.createCriteria();
//            criteria.andTxnIdEqualTo(oriBepsTxn.getId());
//            List<String> list=new ArrayList<>();
//            list.add("00");
//            list.add("01");
//            list.add("04");
//            list.add("05");
//            criteria.andStatusIn(list);
//            List<CpgExceptionInf> exceptionInfs= cpgExceptionInfMapper.selectByExample(example);
//            if(exceptionInfs.size()>0){
//                logger.debug("记录已经录入异常表");
//                continue;
//            }
            String excpType=null;
            String excpDesc=null;


//            01	往账报文发送超时
//            02	往账支付平台发送失败
//            03	往账报文丢弃
//            04	往账报文拒绝
//            05	往账被核押失败
//            10	来账报文核签失败
//            11	来账报文解析失败
//            12	来帐报文丢失

            //2-来账
            if("2".equals(oriBepsTxn.getDrct())){
                excpType="10";
                excpDesc=getDataDesc("EXCEPTION_TYPE",excpType);
                logger.debug("往账异常,\n异常类型:{}-{},\ntxnId:{},\npkgNo:{}-{}",excpType,excpDesc,oriBepsTxn.getId(),pkgNo,pkgName);
            }
            //1-往账
            if("1".equals(oriBepsTxn.getDrct())){
                if("01".equals(oriBepsTxn.getStatus())){
                    logger.debug("交易处理中，计算是否超时,发送时间:{}",oriBepsTxn.getSndTime());
                    String currentDT=DateUtils.currentDateTimeFormat("yyyyMMddHHmmss");
                    if(StringUtils.isNoneBlank(currentDT)){
                        logger.debug("该交易发送时间为空，则认为该交易超时");
                        excpType="01";
                        excpDesc=getDataDesc("EXCEPTION_TYPE",excpType);
                    }else{
                        logger.debug("当前时间:{}",currentDT);
                        long l=DateUtils.dateDiff(oriBepsTxn.getSndTime(),currentDT,"yyyyMMddHHmmss","s");
                        logger.debug("时间差:{}",l);
                        //  当前时间-来账时间>超时时间
                        if(l>300){
                            //如果超时  设置  异常类型，插表
                            excpType="01";
                            excpDesc=getDataDesc("EXCEPTION_TYPE",excpType);
                        }else{
                            //如果没超时，跳过
                            continue;
                        }
                    }
                }
                else if("22".equals(oriBepsTxn.getStatus())){
                    excpType="02";
                    excpDesc=getDataDesc("EXCEPTION_TYPE",excpType);
                }
                else if("21".equals(oriBepsTxn.getStatus())){
                    excpType="03";
                    excpDesc=getDataDesc("EXCEPTION_TYPE",excpType);
                }
                else if("20".equals(oriBepsTxn.getStatus())){
                    /*往账核押错*/
                    if("O4006".equals(oriBepsTxn.getAProcCode())){
                        excpType="05";
                        excpDesc=getDataDesc("EXCEPTION_TYPE",excpType);
                    }else{
                        excpType="04";
                        excpDesc=getDataDesc("EXCEPTION_TYPE",excpType);
                    }
                }else{
                    excpType="04";
                    excpDesc=getDataDesc("EXCEPTION_TYPE",excpType);
                }
                logger.debug("来账异常,\n异常类型:{}-{},\ntxnId:{},\npkgNo:{}-{}",excpType,excpDesc,oriBepsTxn.getId(),pkgNo,pkgName);
            }

            //CpgExceptionInf cpgExceptionInf = cpgExceptionInfMapper.selectByTxnId(oriBepsTxn.getId());
            int count = extExceptionHandleMapper.queryCpgExceptionInf(oriBepsTxn.getId());
            logger.info("异常表中txnid:" + oriBepsTxn.getId() + ",有" + count + "条记录");

            if(count==0||count>1){
                //异常交易入库
                CpgExceptionInf exceptionInf=new CpgExceptionInf();
                exceptionInf.setId(sequenceUtils.getIdByDb("SYSM"));
                exceptionInf.setTxnId(oriBepsTxn.getId());
                if(extCpgDateOrgs.get(0)!=null&&StringUtils.isNotBlank(extCpgDateOrgs.get(0).getBrno())&&StringUtils.isNotBlank(extCpgDateOrgs.get(0).getVdate())){
                    exceptionInf.setBrno(extCpgDateOrgs.get(0).getBrno());
                    exceptionInf.setCpgdate(extCpgDateOrgs.get(0).getVdate());
                }
                exceptionInf.setSysCode("BEPS");
                exceptionInf.setPkgNo(oriBepsTxn.getPkgNo());
                exceptionInf.setWorkdate(oriBepsTxn.getWorkdate());
                exceptionInf.setMsgId(oriBepsTxn.getMsgId());
                exceptionInf.setOrgSender(oriBepsTxn.getOrgSender());
                exceptionInf.setOrgSenderDate(oriBepsTxn.getOrgSenderDate());
                exceptionInf.setDrct(oriBepsTxn.getDrct());
                exceptionInf.setRcvTime(oriBepsTxn.getRcvTime());
                exceptionInf.setSndTime(oriBepsTxn.getSndTime());
                exceptionInf.setAmount(oriBepsTxn.getDtlAmount());

                if(oriBepsTxn.getAProcCode()!=null){
                    exceptionInf.setProcCode(oriBepsTxn.getAProcCode());
                }
                if(oriBepsTxn.getRejectInfo()!=null){
                    exceptionInf.setRejectInfo(oriBepsTxn.getRejectInfo());
                }
                exceptionInf.setExceptionType(excpType);
                exceptionInf.setStatus("00");
                int iRet=cpgExceptionInfMapper.insertSelective(exceptionInf);
                if(iRet!=1){
                    logger.error("入库失败");
                }
            }else{
                CpgExceptionInf cpgExceptionInf = extExceptionHandleMapper.selectByTxnid(oriBepsTxn.getId(), Lock.forUpdate);
                cpgExceptionInf.setExceptionType(excpType);
                cpgExceptionInf.setStatus("00");
                if(oriBepsTxn.getAProcCode()!=null){
                    cpgExceptionInf.setProcCode(oriBepsTxn.getAProcCode());
                }
                if(oriBepsTxn.getRejectInfo()!=null){
                    cpgExceptionInf.setRejectInfo(oriBepsTxn.getRejectInfo());
                }

                cpgExceptionInfMapper.updateByPrimaryKey(cpgExceptionInf);
            }

        }
    }

    /**
     * 可疑异常处理
     * */
    public int getFaultTxn(){
        logger.info("#####################可疑处理#####################");
        /* 查找当前工作日中所有的"可疑异常交易" */
        List<ExtFaultTxn>  faultTxns=extExceptionHandleMapper.queryFaultExcp();
        return 0;
    }

    /**
     * 丢失交易
     * */
    public int getMissTxn(){
        logger.info("#####################可疑处理#####################");
        return 0;
    }

    /**
     * resumeExcp
     * 异常恢复
     * 业务一段时间异常后，后续收到中心的处理，会重置成成功
     * */
    public int resumeExcp(){
        logger.info("#####################异常恢复#####################");
        List<ExtAllExcpTxn> AllExcpTxns=extExceptionHandleMapper.ExtAllExcpTxn();
        logger.info("异常交易:{}条",AllExcpTxns.size());

        for (ExtAllExcpTxn allExcpTxn : AllExcpTxns) {

            String syscode=allExcpTxn.getSyscode();
            String pkgno=allExcpTxn.getPkgno();
            String txn_id=allExcpTxn.getTxnid();
            String sr=null;
            String tableName=null;

            if(pkgno==null||pkgno.length()!=15){
                logger.info("异常报文类型:",allExcpTxn.getPkgno());
                continue;
            }else{

                if("hvps.141.002.01".equals(pkgno)||"hvps.115.001.01".equals(pkgno)||"hvps.116.001.01".equals(pkgno)||
                        "hvps.117.001.01".equals(pkgno)||"hvps.118.001.01".equals(pkgno)||"hvps.132.001.01".equals(pkgno)){
                    sr= pkgno.substring(5, 8) + "_" + pkgno.substring(9, 12);//141_002
                }else{
                    sr=pkgno.substring(5,8);
                }
                if("HVPS".equals(syscode)){//如果是大额交易
                    tableName="CP2_HVPS"+sr;
                    List<ExtAllExcpTxnOrg> extAllExcpTxnOrgs = extExceptionHandleMapper.ExtAllExcpTxnOrg(tableName, txn_id);
                    if(extAllExcpTxnOrgs.size()==0||extAllExcpTxnOrgs.get(0)==null){
                        logger.debug("查询列表为空");
                        continue;

                    }


                    String procCode=null;
                    if(extAllExcpTxnOrgs.get(0).getProcCode()!= null) {
                        procCode = extAllExcpTxnOrgs.get(0).getProcCode().substring(4,8);
                    }
                    String status = extAllExcpTxnOrgs.get(0).getStatus();
                    //CP2_STATUS_SEND        "02" (已发送)
                    //CP2_STATUS_PROC        "05" (已处理)
                    //CP2_STATUS_CANCEL      "04" (已取消)
                    //如果状态为终态, 更新异常处理表状态为03-已恢复
                    if("02".equals(status)&&"0000".equals(procCode)||
                            ("3029").equals(procCode)||"05".equals(status)||"04".equals(status)){
                        logger.info("更新异常处理表");
                        int iRet = extExceptionHandleMapper.updateCpgExceptionInf(allExcpTxn.getId());
                        if(iRet!=1){
                            logger.error("更新异常处理表为03失败");
                            return -1;
                        }
                    }

                }else if("BEPS".equals(syscode)){//如果是小额交易
                    tableName="CP2_BEPSBTMNG";
                    List<ExtAllExcpTxnOrg> extAllExcpTxnOrgs = extExceptionHandleMapper.ExtAllExcpTxnOrg(tableName, txn_id);
                    String procCode=null;
                    if(extAllExcpTxnOrgs.get(0).getProcCode()!= null) {
                        procCode = extAllExcpTxnOrgs.get(0).getProcCode().substring(4,8);
                    }
                    String status = extAllExcpTxnOrgs.get(0).getStatus();
                    if("02".equals(status)&&"0000".equals(procCode)||
                            ("3029").equals(procCode)||"05".equals(status)||"04".equals(status)){
                        logger.info("更新异常处理表");
                        int iRet = extExceptionHandleMapper.updateCpgExceptionInf(allExcpTxn.getId());
                        if(iRet!=1){
                            logger.error("更新异常处理表为03失败");
                            return -1;
                        }
                    }

                }

            }
        }
        return 0;
    }


    /*获取基础数据*/
    public String getDataDesc(String dataType,String dataValue){
        CpgBaseDataExample example=new CpgBaseDataExample();
        CpgBaseDataExample.Criteria criteria= example.createCriteria();
        criteria.andDataTypeEqualTo(dataType);
        criteria.andDataValueEqualTo(dataValue);
        List<CpgBaseData> list=cpgBaseDataMapper.selectByExample(example);
        if(0!=list.size()){
            return null;
        }
        return list.get(0).getDataDesc();
    }


    /**
     * 加锁
     *
     * -1   未配置异常锁参数
     * 1    进程锁已被锁定
     * 0    成功加锁
     *-2    加锁失败
     * */
    public int exceptionLock(){
        //查询异常进程锁
        int lock=extExceptionHandleMapper.querySysParams("CPS2","888888","0009");
        if(lock<0){
            logger.error("异常进程锁参数未配置");
            return -1;
        }
        if(lock==1){
            logger.error("异常进程锁被其他进程占用");
            return 1;
        }
        // 1表示已锁定   0-未上锁
        int iRet=extExceptionHandleMapper.updateSysParams("CPS2","888888","0009",1);
        if(iRet!=1){
            logger.error("上锁失败");
            return -2;
        }
        return 0;
    }

    public int exceptionUnLock(){
        int iRet=extExceptionHandleMapper.updateSysParams("CPS2","888888","0009",0);
        if(iRet!=1){
            logger.error("解锁失败");
            super.setExecStatus(2);
            super.setExecStatusDesc("异常锁解锁失败");
            return -1;
        }
        return 0;
    }
}
