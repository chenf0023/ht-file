package com.huateng.cnaps2.batch.task;

import com.huateng.cnaps2.batch.dal.mapper.ext.CsTxnQueueBatchExtMapper;
import com.huateng.cnaps2.batch.dal.mapper.ext.CsTxnQueueBepsBatchExtMapper;
import com.huateng.cnaps2.batch.dynamicSchedule.BaseTask;
import com.huateng.cnaps2.mapper.Cp2TxnMapper;
import com.huateng.cnaps2.model.Cp2Txn;
import com.huateng.cs.busi.api.IHandlePosition;
import com.huateng.cs.busi.api.model.CheckModel;
import com.huateng.cs.busi.dal.model.CsTxnQueue;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/*
* 定时处理异常记录
* */
@Service
@Slf4j
public class TaskCsQueueBeps extends BaseTask {
    @Resource
    CsTxnQueueBepsBatchExtMapper csTxnQueueBepsBatchExtMapper;
    @Resource
    IHandlePosition iHandlePosition;
    @Resource
    Cp2TxnMapper cp2TxnMapper;


    @Override
    public void init() {
        super.init();
        super.setScheduleId("10");
    }

    @Override
    public void process() {
        log.debug("####################[行内排队-小额]####################");
        super.setProcess();

        dequeue(1);

        super.setSuccess();
        return;
    }

    private void dequeue(int deep){
        /**
         * 1.查询队首节点
         * 2.执行头寸校验
         */
        log.info("===>>>dequeue beps begin");
        CsTxnQueue node = null;
        try {
            log.info("--->>>select dequeue ing node");
            CsTxnQueue dequeueIng = csTxnQueueBepsBatchExtMapper.selectDequeueIng();
            if ( null != dequeueIng ) { //存在正在出队节点
                log.info("===>>>exist node dequeue ing, dequeue end");
                return;
            }

            log.info("--->>>select top node");
            node = csTxnQueueBepsBatchExtMapper.selectTop();
            if ( null == node ) {
                log.info("===>>>not exist top node, dequeue end");
                return;
            }
            node.setStatus("02");//正在出队
            csTxnQueueBepsBatchExtMapper.updateByPrimaryKey(node);

            log.info("--->>>do position check");
            String result = iHandlePosition.execute(node.getCoreId().substring(0, 4), CheckModel.CD_FLAG.CREDIT.value, node.getAmount());
            log.info("--->>>position check result:{}", result);
            Cp2Txn cp2Txn = cp2TxnMapper.selectByPrimaryKey(node.getCoreId());
            if ( null == cp2Txn ) {
                log.info("--->>> cp2Txn not exist, dequeue end");
                return;
            }
            String procResult = iHandlePosition.procResult(result, node.getCoreId(), cp2Txn.getPkgno(), CheckModel.CD_FLAG.CREDIT.value, node.getAmount());
            log.info("--->>>process result:{}", procResult);
            if ( "00".equals(result) && "00".equals(procResult) && deep <= 10 ) {//头寸不足或达到最大深度时停止
                dequeue(deep++);
            }

        } catch (Exception e) {
            if ( null != node && "02".equals(node.getStatus()) ) {
                log.info("--->>>rollback dequeue ing node");
                node.setStatus("00");//正在出队
                csTxnQueueBepsBatchExtMapper.updateByPrimaryKey(node);
            }
            log.error(e.getMessage(), e);
        }
        log.info("===>>>dequeue beps end");
    }





}
