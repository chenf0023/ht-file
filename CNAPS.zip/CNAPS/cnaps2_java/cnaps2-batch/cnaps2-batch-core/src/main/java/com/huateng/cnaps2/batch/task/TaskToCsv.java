package com.huateng.cnaps2.batch.task;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.huateng.cnaps2.batch.dal.mapper.ext.ExtCp2TxnCsvMapper;
import com.huateng.cnaps2.batch.dal.model.ext.Cp2TxnToCsv;
import com.huateng.cnaps2.batch.dynamicSchedule.BaseTask;
import com.huateng.cnaps2.batch.utils.FtpUtils;
import com.huateng.cnaps2.service.common.Cnaps2Dict;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.*;
import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class TaskToCsv extends BaseTask {
    private static final Logger logger = LoggerFactory.getLogger(TaskToCsv.class);
    private static final String CSV_SEPARATOR = ",";

    @Resource
    private ExtCp2TxnCsvMapper extCp2TxnCsvMapper;
    @Resource
    private TaskCpgBankCode taskCpgBankCode;
    @Value("${cnaps.clear.bankcode}")
    private String clearBankCode;

    @Override
    public void init() {
        super.init();
        super.setScheduleId("1");
    }

    @Override
    public void process() {
        logger.debug("####################[定时查询ToCSV任务]####################");
        super.setProcess();
        String brno  = extCp2TxnCsvMapper.queryBrno(clearBankCode, Cnaps2Dict.SYS_CODE.HVPS.value);
        String cpgDate = extCp2TxnCsvMapper.getCpgdate(brno);
        List<Cp2TxnToCsv> cp2Txns = extCp2TxnCsvMapper.selectByPkgNo(cpgDate);
        File file = null;
        try {
            String fileName = "CPG2LRR_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".csv";
            //动态生成文件和文件名
             file = new File( extCp2TxnCsvMapper.getCsvUrl()+ fileName);
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
//            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName), "UTF-8"));

            StringBuffer fieldNames = new StringBuffer();
            for (Field field : Cp2TxnToCsv.class.getDeclaredFields()) {
                JsonProperty annotation = field.getAnnotation(JsonProperty.class);
                if (null == annotation) {
                    fieldNames.append(field.getName());
                    fieldNames.append(CSV_SEPARATOR);
                }
            }
            fieldNames.deleteCharAt(fieldNames.length() - 1);
            bw.write(fieldNames.toString());
            bw.newLine();

            for (Cp2TxnToCsv cp2TxnToCsv : cp2Txns) {
                StringBuffer oneLine = new StringBuffer();
                oneLine.append("\"").append(cp2TxnToCsv.getCoreId().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getUpstreamId()== null ? "" : cp2TxnToCsv.getUpstreamId().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getMsgId()== null ? "" : cp2TxnToCsv.getMsgId().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getBtId() == null? "" : cp2TxnToCsv.getBtId().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getSysCode()== null? "" : cp2TxnToCsv.getSysCode().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getBrno()== null? "" : cp2TxnToCsv.getBrno().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getWorkDate()== null? "" : cp2TxnToCsv.getWorkDate().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getTxnDate()== null? "" : cp2TxnToCsv.getTxnDate().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getVdate()== null? "" : cp2TxnToCsv.getVdate().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getDrct()== null? "" : cp2TxnToCsv.getDrct().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getSource()== null? "" : cp2TxnToCsv.getSource().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getPkgNo()== null? "" : cp2TxnToCsv.getPkgNo().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getProcStatus()== null? "" : cp2TxnToCsv.getProcStatus().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getSndStBrno()== null? "" : cp2TxnToCsv.getSndStBrno().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getRcvStBrno()== null? "" : cp2TxnToCsv.getRcvStBrno().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getPayerName()== null? "" : cp2TxnToCsv.getPayerName().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getPayerAddr()== null? "" : cp2TxnToCsv.getPayerAddr().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getPayerActno()== null? "" : cp2TxnToCsv.getPayerActno().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getPayerAccBrno()== null? "" : cp2TxnToCsv.getPayerAccBrno().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getPayerAccBrName()== null? "" : cp2TxnToCsv.getPayerAccBrName().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getPayerBrno()== null? "" : cp2TxnToCsv.getPayerBrno().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getPayeeBrno()== null? "" : cp2TxnToCsv.getPayeeBrno().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getPayeeName()== null? "" : cp2TxnToCsv.getPayeeName().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getPayeeAddr()== null? "" : cp2TxnToCsv.getPayeeAddr().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getPayeeActno()== null? "" : cp2TxnToCsv.getPayeeActno().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getPayeeAccBrName()== null? "" : cp2TxnToCsv.getPayeeAccBrName().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getPayeeAccBrno()== null? "" : cp2TxnToCsv.getPayeeAccBrno().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getCurcd()== null? "" : cp2TxnToCsv.getCurcd().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getAmount()== null? "" : translateAMount(cp2TxnToCsv.getAmount().trim()));
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getBizCtgyCode()== null? "" : cp2TxnToCsv.getBizCtgyCode().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getBizTypeCode()== null? "" : cp2TxnToCsv.getBizTypeCode().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getChkDate()== null? "" : cp2TxnToCsv.getChkDate().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getChkRound()== null? "" : cp2TxnToCsv.getChkRound().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getClrDate()== null? "" : cp2TxnToCsv.getClrDate().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getOriId()== null? "" : cp2TxnToCsv.getOriId().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getOriPkgId()== null? "" : cp2TxnToCsv.getOriPkgId().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getOriSender()== null? "" : cp2TxnToCsv.getOriSender().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getProcCode()== null? "" : cp2TxnToCsv.getProcCode().trim());
                oneLine.append("\"").append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2TxnToCsv.getProcInfo()== null? "" : cp2TxnToCsv.getProcInfo().trim());
                oneLine.append("\"");
                bw.write(oneLine.toString());
                bw.newLine();
            }
            bw.flush();
            bw.close();
            logger.info("生成Csv文件完成,地址"+file.getPath());
        } catch (UnsupportedEncodingException e) {
        } catch (FileNotFoundException e) {
        } catch (IOException e) {
        }
        try {
            logger.debug("ftp -----------------connect");
            FtpUtils.getConnect(extCp2TxnCsvMapper.getFtpaddress(), extCp2TxnCsvMapper.getFtpPort(), extCp2TxnCsvMapper.getFtpUserName(), extCp2TxnCsvMapper.getFtpUserPsd());
            logger.debug("ftp -----------------upload");
            FtpUtils.uploadFile(file.getPath(),extCp2TxnCsvMapper.getFtpUrl(),file.getName());
            logger.debug("ftp ----------------success");
            FtpUtils.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        logger.info("拿CP2_BANKCODE数据");
        taskCpgBankCode.process();

    }

    public String translateAMount(String amount){
       return   new StringBuilder(amount).insert(amount.length()-2, ".").toString();
    }
}

