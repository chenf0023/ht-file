package com.huateng.cnaps2.batch.utils;

import com.huateng.cs.busi.api.model.CheckRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class STPCheckProc4Ftd implements STPCheckProc {
    private static final Logger logger = LoggerFactory.getLogger(STPCheckProc4Ftd.class);
    @Resource
    STPCheckHelperService stpCheckHelperService;

    @Override
    public void proc(CheckRequest... params) {

        // Map<String, CheckResult> checkResultMap = stpCheckHelperService.doCheck(params);
        //
        // StringBuilder checkDesc = new StringBuilder();
        // Iterator<Map.Entry<String, CheckResult>> checkResults = checkResultMap.entrySet().iterator();
        // while ( checkResults.hasNext() ){
        //     Map.Entry<String, CheckResult> entry = checkResults.next();
        //     CheckResult checkResult = entry.getValue();
        //     logger.debug("校验类型：{}",checkResult.getType());
        //     logger.debug("校验结果：{}", checkResult);
        //     switch (checkResult.getType()) {
        //
        //         case CheckRequest.CHECK_TYPE.OUTWARD_CHECK_AMOUNT_LARGE_CODE :
        //             if( CheckResult.RESULT_STATUS.SUCCESS.equals(checkResult.getStatus()) ){
        //                 if ( CheckResult.RESULT_CODE.SUCCESS.equals(checkResult.getCode()) ){
        //                     logger.debug("大金额校验通过");
        //                 } else {
        //                     logger.debug("大金额校验不通过");
        //                     STPCheckHelperService.jointResultDesc(checkDesc, checkResult.getDesc());
        //                 }
        //             } else if ( CheckResult.RESULT_STATUS.UNCHECK.equals(checkResult.getStatus()) ) {
        //                 logger.debug("校验未启用");//miracle 未启用状态的处理逻辑不确定
        //             } else {
        //                 logger.debug("校验状态异常");
        //                 checkDesc.append(checkResult.getDesc());
        //             }
        //             break;
        //
        //         case CheckRequest.CHECK_TYPE.OUTWARD_CHECK_CORPORATE2INDIVIDUAL_CODE :
        //             if(CheckResult.RESULT_STATUS.SUCCESS.equals(checkResult.getStatus())){
        //                 if (CheckResult.RESULT_CODE.SUCCESS.equals(checkResult.getCode())){
        //                     if(CheckResult.CI_STATUS.C2I_NOT.equals(checkResult.getCIStatus())){
        //                         logger.debug("不是公转私");
        //                     }else if(CheckResult.CI_STATUS.C2I_UNABLE.equals(checkResult.getCIStatus())){
        //                         logger.debug("超过公转私配额");
        //                         STPCheckHelperService.jointResultDesc(checkDesc, checkResult.getDesc());
        //                     }else if(CheckResult.CI_STATUS.C2I_ENABLE.equals(checkResult.getCIStatus())){
        //                         logger.debug("不超过公转私配额");
        //                     }
        //                 } else {
        //                     logger.debug("公转私校验不通过");
        //                     STPCheckHelperService.jointResultDesc(checkDesc, checkResult.getDesc());
        //                 }
        //             } else if ( CheckResult.RESULT_STATUS.UNCHECK.equals(checkResult.getStatus()) ) {
        //                 logger.debug("校验未启用");//miracle 未启用状态的处理逻辑不确定
        //             } else {
        //                 logger.debug("校验状态异常");
        //                 STPCheckHelperService.jointResultDesc(checkDesc, checkResult.getDesc());
        //             }
        //             break;
        //
        //         case CheckRequest.CHECK_TYPE.OUTWARD_CHECK_KEYWORD_CODE :
        //             if(CheckResult.RESULT_STATUS.SUCCESS.equals(checkResult.getStatus())){
        //                 if (CheckResult.RESULT_CODE.SUCCESS.equals(checkResult.getCode())){
        //                     logger.debug("未匹配到关键字");
        //                 }else {
        //                     logger.debug("匹配到关键字");
        //                     STPCheckHelperService.jointResultDesc(checkDesc, checkResult.getDesc());
        //                 }
        //             } else if ( CheckResult.RESULT_STATUS.UNCHECK.equals(checkResult.getStatus()) ) {
        //                 logger.debug("校验未启用");//miracle 未启用状态的处理逻辑不确定
        //             } else {
        //                 logger.debug("校验状态异常");
        //                 STPCheckHelperService.jointResultDesc(checkDesc, checkResult.getDesc());
        //             }
        //             break;
        //
        //         case CheckRequest.CHECK_TYPE.OUTWARD_CHECK_SUSPICIOUS_DUPLICATION_CODE :
        //             if(CheckResult.RESULT_STATUS.SUCCESS.equals(checkResult.getStatus())){
        //                 if (CheckResult.RESULT_STATUS.SUCCESS.equals(checkResult.getStatus()) &&
        //                         CheckResult.RESULT_CODE.SUCCESS.equals(checkResult.getCode())){
        //                     logger.debug("疑似重帐检查通过");
        //                 }else {
        //                     logger.debug("存在疑似重帐");
        //                     STPCheckHelperService.jointResultDesc(checkDesc, checkResult.getDesc());
        //                 }
        //             } else if ( CheckResult.RESULT_STATUS.UNCHECK.equals(checkResult.getStatus()) ) {
        //                 logger.debug("校验未启用");//miracle 未启用状态的处理逻辑不确定
        //             } else {
        //                 logger.debug("校验状态异常");
        //                 STPCheckHelperService.jointResultDesc(checkDesc, checkResult.getDesc());
        //             }
        //             break;
        //     }
        // }
        // if ( 0 != checkDesc.length() ) {
        //     throw new BaseException(checkDesc.toString());
        // }
    }


}
