package com.huateng.cnaps2.comm.service.impl;

import com.huateng.cnaps2.comm.event.Cnaps2SendFailEvent;
import com.huateng.cnaps2.comm.event.Cnpas2RecvFailEvent;
import com.huateng.comm.support.base.ComReceiveException;
import com.huateng.comm.support.base.ComSendException;
import com.huateng.service.error.ErrorController;
import com.huateng.service.error.ErrorHandle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;

import java.util.Map;

@ErrorController
public class Cnaps2CommExcpetionHandle {
    private ApplicationEventPublisher applicationEventPublisher;

    @ErrorHandle
    public void handleSender(ComSendException comSendException) {
        Cnaps2SendFailEvent cnaps2SendFailEvent = new Cnaps2SendFailEvent();
        Map<String, String> head = comSendException.getInfo();
        cnaps2SendFailEvent.setId(head.get("id"));
        cnaps2SendFailEvent.setPkgNo(head.get("pkgNo"));

        applicationEventPublisher.publishEvent(cnaps2SendFailEvent);
    }

    @ErrorHandle
    public void handleRecv(ComReceiveException comReceiveException) {
        Cnpas2RecvFailEvent cnpas2RecvFailEvent = new Cnpas2RecvFailEvent();
        cnpas2RecvFailEvent.setCommInfo(comReceiveException.getInfo());
        applicationEventPublisher.publishEvent(cnpas2RecvFailEvent);
    }

    @Autowired
    public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
        this.applicationEventPublisher = applicationEventPublisher;
    }
}
