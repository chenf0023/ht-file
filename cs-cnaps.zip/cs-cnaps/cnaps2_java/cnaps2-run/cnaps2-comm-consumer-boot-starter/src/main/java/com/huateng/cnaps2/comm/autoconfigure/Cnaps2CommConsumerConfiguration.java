package com.huateng.cnaps2.comm.autoconfigure;

import com.huateng.service.fusion.autoconfigure.ServiceClient;
import org.springframework.context.annotation.PropertySource;

@PropertySource("classpath:cnaps2-comm-service.properties")
@ServiceClient("service.cnaps2-comm")
public class Cnaps2CommConsumerConfiguration {

}
