package com.huateng.cnaps2.comm.autoconfigure;

import com.huateng.cnaps2.comm.Cnaps2CommConfiguration;
import com.huateng.service.fusion.autoconfigure.ServiceServer;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;

@PropertySource({"classpath:cnaps2-comm-service.properties"})
@Import(Cnaps2CommConfiguration.class)
@ServiceServer("service.cnaps2-comm")
public class Cnaps2CommProviderConfiguration {

}
