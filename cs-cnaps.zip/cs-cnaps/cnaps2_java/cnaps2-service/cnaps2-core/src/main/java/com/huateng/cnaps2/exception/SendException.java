package com.huateng.cnaps2.exception;

import com.huateng.bank.message.BnkMsg;

public class SendException extends RuntimeException {
    private BnkMsg bnkMsg;

    public BnkMsg getBnkMsg() {
        return bnkMsg;
    }

    public SendException(Throwable cause, BnkMsg bnkMsg) {
        super(cause);
        this.bnkMsg = bnkMsg;
    }

    public SendException(String message, BnkMsg bnkMsg) {
        super(message);
        this.bnkMsg = bnkMsg;
    }

    @Override
    public String getMessage() {
        return "SendException{" +
                "bnkMsg=" + bnkMsg +
                '}';
    }
}
