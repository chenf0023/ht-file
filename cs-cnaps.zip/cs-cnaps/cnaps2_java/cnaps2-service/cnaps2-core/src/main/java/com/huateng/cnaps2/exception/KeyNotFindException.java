package com.huateng.cnaps2.exception;

public class KeyNotFindException extends RuntimeException {
    public KeyNotFindException(String message) {
        super(message);
    }
}
