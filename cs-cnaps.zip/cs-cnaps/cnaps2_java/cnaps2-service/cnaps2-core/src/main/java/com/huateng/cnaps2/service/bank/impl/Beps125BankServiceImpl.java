package com.huateng.cnaps2.service.bank.impl;

import com.huateng.bank.message.BnkMsg;
import com.huateng.cnaps2.bank.service.Beps125BankService;
import com.huateng.cnaps2.mapper.bankMapper.Cp2Beps125BankMapper;
import com.huateng.cnaps2.model.bankModel.Cp2Beps125Bank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Description
 * @Author miracle
 * @Date 2021/11/5 10:49
 * @Version 1.0
 */
@Service
public class Beps125BankServiceImpl implements Beps125BankService {
    private static final Logger logger = LoggerFactory.getLogger(Beps125BankServiceImpl.class);

    @Autowired
    Cp2Beps125BankMapper cp2Beps125BankMapper;

    @Override
    public void receive(BnkMsg bnkMsg) {//todo demo未验证业务正确性
        /*获取批次表信息 */
        Cp2Beps125Bank batchInfo = cp2Beps125BankMapper.selBatchInfo(bnkMsg.id);
        if(batchInfo==null){//==ERR_TOP_DBS_NOTFOUND
            logger.error("CP2_BEPSBTMNG message not found");
            return;
        }

        /* 获取内部机构号 */
        Cp2Beps125Bank TNXInfo = cp2Beps125BankMapper.selTNXInfo(bnkMsg.id);
        if(TNXInfo != null) {//!= ERR_TOP_DBS_OK
            logger.error("CP2_TXN message not found");
            return;
        }

        /*获取NPC信息*/
        Cp2Beps125Bank NPCInfo = cp2Beps125BankMapper.selNPCInfo(bnkMsg.id);
        if(NPCInfo == null) {// != ERR_TOP_DBS_OK != ERR_TOP_DBS_NOTFOUND
            logger.error("CP2_BEPS125 message not found");
            return;
        }

        /*更新125表该批次交易的状态*/
        cp2Beps125BankMapper.updateCP2Beps125(bnkMsg.resndFlag, bnkMsg.workDate, bnkMsg.pkgNo);

        /*更新批次表的状态*/
        cp2Beps125BankMapper.updateCP2Bepsbtmng(bnkMsg.resndFlag, bnkMsg.workDate, bnkMsg.pkgNo);

        /*更新TXN表的状态*/
        cp2Beps125BankMapper.updateCP2TXN(bnkMsg.resndFlag, bnkMsg.workDate, bnkMsg.pkgNo);

    }
}