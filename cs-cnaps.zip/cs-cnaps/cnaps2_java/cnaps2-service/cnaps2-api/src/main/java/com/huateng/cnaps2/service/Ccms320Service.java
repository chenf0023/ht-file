package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_320_001_01;

public interface Ccms320Service extends IReceive<Ccms_320_001_01>, ISend<Ccms_320_001_01>{
}
