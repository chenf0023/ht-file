package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_313_001_02;

public interface Ccms313_02Service extends IReceive<Ccms_313_001_02>, ISend<Ccms_313_001_02>{
}
