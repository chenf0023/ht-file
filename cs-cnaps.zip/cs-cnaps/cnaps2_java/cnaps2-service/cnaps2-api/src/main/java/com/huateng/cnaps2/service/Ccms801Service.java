package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_801_001_02;

public interface Ccms801Service extends IReceive<Ccms_801_001_02>{
}
