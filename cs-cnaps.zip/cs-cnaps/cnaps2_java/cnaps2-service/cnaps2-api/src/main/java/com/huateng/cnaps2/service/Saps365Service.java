package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Saps_365_001_01;

public interface Saps365Service extends ISend<Saps_365_001_01> {
}
