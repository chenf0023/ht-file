package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_141_002_01;

public interface Hvps141_002Service extends IReceive<Hvps_141_002_01>{
}
