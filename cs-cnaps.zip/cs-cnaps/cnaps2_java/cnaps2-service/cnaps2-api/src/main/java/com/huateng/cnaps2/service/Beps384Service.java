package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_384_001_01;

public interface Beps384Service extends IReceive<Beps_384_001_01>{
}
