package com.huateng.cnaps2.service;


import com.huateng.cnaps2.message.Beps_371_001_01;

public interface Beps371Service extends IReceive<Beps_371_001_01>, ISend<Beps_371_001_01>{
}
