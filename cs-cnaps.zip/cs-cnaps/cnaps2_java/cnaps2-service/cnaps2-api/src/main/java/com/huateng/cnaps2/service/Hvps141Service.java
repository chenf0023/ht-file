package com.huateng.cnaps2.service;

import com.huateng.bank.message.BnkMsg;
import com.huateng.cnaps2.message.Hvps_141_001_01;

public interface Hvps141Service extends IReceive<Hvps_141_001_01>{
}
