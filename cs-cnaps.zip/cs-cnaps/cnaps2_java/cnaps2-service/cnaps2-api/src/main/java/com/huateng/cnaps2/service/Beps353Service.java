package com.huateng.cnaps2.service;



import com.huateng.cnaps2.message.Beps_353_001_01;


public interface Beps353Service extends IReceive<Beps_353_001_01>, ISend<Beps_353_001_01> {
}
