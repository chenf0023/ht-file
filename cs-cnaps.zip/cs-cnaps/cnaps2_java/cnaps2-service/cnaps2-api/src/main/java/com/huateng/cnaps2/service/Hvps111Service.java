package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_111_001_01;

public interface Hvps111Service extends IReceive<Hvps_111_001_01>, ISend<Hvps_111_001_01> {
}
