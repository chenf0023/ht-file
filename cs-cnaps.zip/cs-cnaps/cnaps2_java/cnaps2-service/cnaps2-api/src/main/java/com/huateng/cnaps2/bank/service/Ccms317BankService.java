package com.huateng.cnaps2.bank.service;

import com.huateng.bank.message.BnkMsg;

public interface Ccms317BankService extends BankBaseService {
    void receive(BnkMsg bnkMsg);
}
