package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Saps_364_001_01;

public interface Saps364Service extends IReceive<Saps_364_001_01>{
}
