package com.huateng.cnaps2.service;

/**
 * 带返回值的发送接口可以捕获异常
 */
public interface ISendSuper{
    String send(String pkgNo, String id);
}
