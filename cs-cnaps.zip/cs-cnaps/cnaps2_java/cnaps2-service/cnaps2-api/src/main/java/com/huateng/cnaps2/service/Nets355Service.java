package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Nets_355_001_01;

public interface Nets355Service extends IReceive<Nets_355_001_01>{
}
