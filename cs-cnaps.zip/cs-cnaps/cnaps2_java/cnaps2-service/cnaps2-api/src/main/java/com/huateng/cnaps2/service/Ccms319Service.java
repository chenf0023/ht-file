package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_319_001_01;

public interface Ccms319Service extends IReceive<Ccms_319_001_01>, ISend<Ccms_319_001_01>{
}
