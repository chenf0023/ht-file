package com.huateng.cnaps2.service;


import com.huateng.cnaps2.message.Beps_376_001_01;

public interface Beps376Service extends IReceive<Beps_376_001_01>{
}
