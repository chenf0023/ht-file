package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_418_001_01;

public interface Beps418Service extends IReceive<Beps_418_001_01>, ISend<Beps_418_001_01>{
}
