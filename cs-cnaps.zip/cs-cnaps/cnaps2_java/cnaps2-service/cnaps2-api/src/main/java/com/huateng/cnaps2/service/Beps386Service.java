package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_386_001_01;

public interface Beps386Service extends IReceive<Beps_386_001_01> {
}
