package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_999_001_01;

public interface Ccms999Service extends IReceive<Ccms_999_001_01>{
}
