package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Nets_376_001_01;

public interface Nets376Service extends ISend<Nets_376_001_01> {
}
