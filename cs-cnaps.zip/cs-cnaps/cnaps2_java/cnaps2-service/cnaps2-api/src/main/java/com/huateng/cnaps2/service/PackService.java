package com.huateng.cnaps2.service;

import java.util.List;

public interface PackService {
    void packAll(String brno);
    void pack(String messageType, String brno);
    void pack(String messageType, String brno, List<String> idList);
    void packAll(String brno, String relationship, String minirecords);
    void pack(String messageType, String brno, String relationship, String minirecords);
}
