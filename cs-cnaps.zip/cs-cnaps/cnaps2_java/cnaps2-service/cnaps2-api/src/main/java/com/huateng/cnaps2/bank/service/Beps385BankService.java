package com.huateng.cnaps2.bank.service;

import com.huateng.bank.message.BnkMsg;

public interface Beps385BankService extends BankBaseService {
    void receive(BnkMsg bnkMsg);
}
