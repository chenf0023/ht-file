package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_381_001_02;

public interface Beps381_02Service extends IReceive<Beps_381_001_02>, ISend<Beps_381_001_02> {
}
