package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_711_001_01;
import com.huateng.cnaps2.model.Cp2Beps721;
import com.huateng.cnaps2.model.Cp2Hvps711;

import java.util.List;

public interface ReconService {
    void hvpsPrerecon(String brno, String reconDate);
    void bepsPreRecon(String brno, String reconDate);
    void bepsDetailRecon(String oriId, String id);
    void hvpsDetailRecon(String brno, String reconDate, String oldId);
    void bepsSumRecon(List<Cp2Beps721> cp2Beps721List, String pkg);
    void hvpsSumRecon(List<Cp2Hvps711> cp2Hvps711List, Hvps_711_001_01 msg);
}
