package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_310_001_01;

public interface Ccms310Service extends IReceive<Ccms_310_001_01>, ISend<Ccms_310_001_01>{
}
