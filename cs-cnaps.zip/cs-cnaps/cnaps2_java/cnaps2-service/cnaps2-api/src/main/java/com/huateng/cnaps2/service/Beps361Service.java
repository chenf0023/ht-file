package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_361_001_01;

public interface Beps361Service extends ISend<Beps_361_001_01> {
}
