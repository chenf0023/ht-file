package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_365_001_01;

public interface Beps367Service extends ISend<Beps_365_001_01>{
}
