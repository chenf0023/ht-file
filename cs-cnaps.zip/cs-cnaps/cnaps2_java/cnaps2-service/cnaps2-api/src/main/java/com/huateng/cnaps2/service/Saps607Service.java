package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Saps_607_001_01;

public interface Saps607Service extends IReceive<Saps_607_001_01>{
}
