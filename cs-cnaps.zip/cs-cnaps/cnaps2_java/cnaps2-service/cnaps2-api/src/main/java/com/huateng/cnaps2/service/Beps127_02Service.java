package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_127_001_02;

public interface Beps127_02Service extends IReceive<Beps_127_001_02>, ISend<Beps_127_001_02>{
}
