package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_921_001_01;

public interface Ccms921Service extends IReceive<Ccms_921_001_01>{
}
