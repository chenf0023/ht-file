package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_122_001_01;

public interface Beps122Service extends IReceive<Beps_122_001_01>, ISend<Beps_122_001_01>{
}
