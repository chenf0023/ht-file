package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_318_001_01;

public interface Ccms318Service extends IReceive<Ccms_318_001_01>, ISend<Ccms_318_001_01>{
}
