package com.huateng.cnaps2.support;

public interface ToCtl {
    boolean cp2LockToCtl(String id, String pkgNo);
    boolean cp2UnlockToCtl(String id);
}
