package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Nets_405_001_01;

public interface Nets405Service extends ISend<Nets_405_001_01> {
}
