package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_123_001_01;

public interface Beps123Service extends IReceive<Beps_123_001_01>, ISend<Beps_123_001_01> {
}
