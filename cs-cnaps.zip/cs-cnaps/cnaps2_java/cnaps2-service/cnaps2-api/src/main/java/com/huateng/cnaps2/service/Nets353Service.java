package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Nets_353_001_01;

public interface Nets353Service extends ISend<Nets_353_001_01> {
}
