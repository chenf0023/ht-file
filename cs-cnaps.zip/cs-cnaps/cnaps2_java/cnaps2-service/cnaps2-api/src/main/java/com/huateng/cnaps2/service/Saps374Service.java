package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Saps_374_001_01;

public interface Saps374Service extends IReceive<Saps_374_001_01>, ISend<Saps_374_001_01>{
}
