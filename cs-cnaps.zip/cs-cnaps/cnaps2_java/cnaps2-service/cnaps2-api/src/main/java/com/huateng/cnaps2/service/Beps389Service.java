package com.huateng.cnaps2.service;


import com.huateng.cnaps2.message.Beps_389_001_01;

public interface Beps389Service extends ISend<Beps_389_001_01> {
}
