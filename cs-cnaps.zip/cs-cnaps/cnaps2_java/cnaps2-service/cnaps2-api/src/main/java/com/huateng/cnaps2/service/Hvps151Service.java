package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_151_001_01;

public interface Hvps151Service extends ISend<Hvps_151_001_01> {
}
