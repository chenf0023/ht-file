package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Nets_350_001_01;

public interface Nets350Service extends ISend<Nets_350_001_01> {
}
