package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_913_001_01;

public interface Ccms913Service extends IReceive<Ccms_913_001_01>{
}
