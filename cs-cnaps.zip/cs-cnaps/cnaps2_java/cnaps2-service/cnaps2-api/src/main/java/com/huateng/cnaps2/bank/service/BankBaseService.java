package com.huateng.cnaps2.bank.service;

import com.huateng.bank.message.BnkMsg;

public interface BankBaseService {
    void receive(BnkMsg bnkMsg);
}
