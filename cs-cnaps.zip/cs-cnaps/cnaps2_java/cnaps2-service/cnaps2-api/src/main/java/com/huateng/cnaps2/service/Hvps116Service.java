package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_116_001_01;

public interface Hvps116Service extends IReceive<Hvps_116_001_01>, ISend<Hvps_116_001_01> {
}
