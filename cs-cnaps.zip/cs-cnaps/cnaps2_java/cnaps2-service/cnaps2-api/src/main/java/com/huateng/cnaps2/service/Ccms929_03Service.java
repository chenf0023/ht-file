package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_929_001_03;

public interface Ccms929_03Service extends ISend<Ccms_929_001_03>{
}
