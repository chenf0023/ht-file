package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_321_001_01;

public interface Ccms321Service extends IReceive<Ccms_321_001_01>, ISend<Ccms_321_001_01>{
}
