package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_121_001_01;
import com.huateng.cnaps2.message.Beps_122_001_01;
import com.huateng.cnaps2.message.Hvps_111_001_01;
import com.huateng.cnaps2.message.Hvps_112_001_01;
import com.huateng.cnaps2.model.Cp2Beps121;
import com.huateng.cnaps2.model.Cp2Beps122;
import com.huateng.cnaps2.model.Cp2Hvps111;
import com.huateng.cnaps2.model.Cp2Hvps112;

public interface CallBusiCs {
    void callCsBusi(String source,String channel,String msgType,Object data);

    Hvps_111_001_01 genMessage(Cp2Hvps111 cp2Hvps111);

    Hvps_112_001_01 genMessage(Cp2Hvps112 cp2Hvps112);

    Beps_121_001_01 genBeps121(Cp2Beps121 cp2Beps121);

    Beps_122_001_01 genBeps122(Cp2Beps122 cp2Beps122);
}
