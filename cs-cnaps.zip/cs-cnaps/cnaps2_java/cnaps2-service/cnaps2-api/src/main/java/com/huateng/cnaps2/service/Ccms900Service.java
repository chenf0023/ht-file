package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_900_001_02;

public interface Ccms900Service extends IReceive<Ccms_900_001_02>{
}
