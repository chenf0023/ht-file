package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_404_001_01;

public interface Beps404Service extends IReceive<Beps_404_001_01>, ISend<Beps_404_001_01>{
}
