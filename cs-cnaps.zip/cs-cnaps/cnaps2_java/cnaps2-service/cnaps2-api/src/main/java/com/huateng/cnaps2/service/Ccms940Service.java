package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_940_001_01;

public interface Ccms940Service extends ISend<Ccms_940_001_01>{
}
