package com.huateng.cnaps2.service;

import com.huateng.bank.message.BnkMsg;
import com.huateng.cnaps2.message.Hvps_112_001_01;

public interface Hvps112Service extends IReceive<Hvps_112_001_01>, ISend<Hvps_112_001_01> {
}
