package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_118_001_01;

public interface Hvps118Service extends IReceive<Hvps_118_001_01>, ISend<Hvps_118_001_01> {
}
