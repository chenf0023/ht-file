package com.huateng.cnaps2.service;


import com.huateng.cnaps2.message.Beps_375_001_01;

public interface Beps375Service extends ISend<Beps_375_001_01>{
}
