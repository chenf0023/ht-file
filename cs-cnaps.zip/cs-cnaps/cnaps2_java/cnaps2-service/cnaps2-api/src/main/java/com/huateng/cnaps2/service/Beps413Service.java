package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_413_001_01;

public interface Beps413Service extends ISend<Beps_413_001_01> {
}
