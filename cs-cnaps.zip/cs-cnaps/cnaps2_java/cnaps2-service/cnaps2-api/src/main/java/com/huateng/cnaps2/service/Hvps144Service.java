package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_144_001_01;

public interface Hvps144Service extends IReceive<Hvps_144_001_01> {
}
