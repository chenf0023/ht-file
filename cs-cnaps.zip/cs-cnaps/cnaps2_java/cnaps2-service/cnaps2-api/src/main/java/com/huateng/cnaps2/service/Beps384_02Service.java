package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_384_001_02;

public interface Beps384_02Service extends IReceive<Beps_384_001_02>{
}
