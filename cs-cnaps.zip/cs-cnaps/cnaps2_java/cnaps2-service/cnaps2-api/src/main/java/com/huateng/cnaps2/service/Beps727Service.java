package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_727_001_01;

public interface Beps727Service extends ISend<Beps_727_001_01>{

}
