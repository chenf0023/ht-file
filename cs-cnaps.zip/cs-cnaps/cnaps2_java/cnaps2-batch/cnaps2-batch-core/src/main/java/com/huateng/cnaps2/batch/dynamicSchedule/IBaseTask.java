package com.huateng.cnaps2.batch.dynamicSchedule;

public interface IBaseTask {
    public void check();

    public void before();

    public void process();
    public void after();
}
