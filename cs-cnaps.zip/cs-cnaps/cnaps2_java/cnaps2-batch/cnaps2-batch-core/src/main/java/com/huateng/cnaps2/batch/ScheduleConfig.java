package com.huateng.cnaps2.batch;

import org.mybatis.spring.annotation.MapperScan;
import org.mybatis.spring.annotation.MapperScans;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableScheduling
@ComponentScans({
        @ComponentScan("com.huateng.cnaps2.batch")
})
@MapperScans({
        @MapperScan("com.huateng.cnaps2.mapper"),
        @MapperScan("com.huateng.cpg.mapper")
})
public class ScheduleConfig {
}
