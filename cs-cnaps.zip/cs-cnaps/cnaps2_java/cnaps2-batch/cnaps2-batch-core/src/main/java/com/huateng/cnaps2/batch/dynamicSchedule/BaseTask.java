package com.huateng.cnaps2.batch.dynamicSchedule;

import com.huateng.cnaps2.batch.dal.mapper.Cp2ScheduleTaskLogsMapper;
import com.huateng.cnaps2.batch.dal.model.Cp2ScheduleTaskLogs;
import com.huateng.cnaps2.batch.utils.DateUtils;
import com.huateng.cnaps2.batch.utils.SequenceUtils;
import com.huateng.cnaps2.batch.utils.SpringUtils;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class BaseTask implements Runnable{
    private static final Logger logger = LoggerFactory.getLogger(BaseTask.class);

    private static Cp2ScheduleTaskLogsMapper mapper=(Cp2ScheduleTaskLogsMapper)SpringUtils.getBean("cp2ScheduleTaskLogsMapper");
    //唯一id
    private String id;
    //任务id
    private String scheduleId;
    //执行参数
    private String scheduleParam;
    //执行日期
    private String execDate;
    //执行时间
    private Date execTime;
    //执行结束时间
    private Date execEndTime;
    //执行次数
    private int execCount;
    //重试次数
    private int retryCount;
    //执行状态
    private int execStatus;
    //执行结果描述
    private String execStatusDesc;

    @Override
    public void run() {
        this.init();
        this.check();
        this.before();
        try {
            this.process();
            this.after();
        }catch (Exception e){
            e.printStackTrace();
            this.exception(e);
        }
    }
    /**
     * 初始化
     * */
    public void init(){
        logger.debug("#######init#######");
        id= SequenceUtils.getId();
        execDate= DateUtils.currentDateTimeFormat("yyyyMMdd");
        execTime=new Date();
        execEndTime=new Date();
        execCount=1;        //执行次数
        retryCount=0;       //重试次数
        execStatus=0;       //0-初始化
        execStatusDesc="任务初始化";
    }
    /**
     * 检查
     * */
    public void check(){
        logger.debug("#######check#######");
    }
    /**
     * 前处理
     * */
    public void before(){
        logger.debug("#######before#######");
        insertLog();

    }
    /**
     * 处理
     * */
    public void process(){
        logger.debug("#######process#######");
    }
    /**
     * 后处理
     * */
    public void after(){
        logger.debug("#######after#######");
        updateLog();
    }

    /**
     * 异常处理
     * */
    public void exception(Exception e){
        logger.error("#######excetion#######");
        execStatus=4;
        execStatusDesc="定时任务异常退出";
        execEndTime=new Date();
        updateLog();
    }

    /**
     *  插入任务日志
     * */
    public int insertLog(){
        Cp2ScheduleTaskLogs record=new Cp2ScheduleTaskLogs();
        record.setId(id);
        record.setScheduleId(scheduleId);
        record.setScheduleParam(scheduleParam);
        record.setExecDate(execDate);
        record.setExecTime(execTime);
        record.setExecEndTime(execEndTime);
        record.setExecCount(BigDecimal.valueOf(execCount));
        record.setRetryCount(BigDecimal.valueOf(retryCount));
        record.setExecStatus(BigDecimal.valueOf(execStatus));
        record.setExecStatusDesc(execStatusDesc);
        return mapper.insert(record);
    }

    /**
     *  跟新任务日志
     * */
    public int updateLog(){
        Cp2ScheduleTaskLogs record=new Cp2ScheduleTaskLogs();
        record.setId(id);
        record.setScheduleId(scheduleId);
        record.setScheduleParam(scheduleParam);
        record.setExecDate(execDate);
        record.setExecTime(execTime);
        record.setExecEndTime(execEndTime);
        record.setExecCount(BigDecimal.valueOf(execCount));
        record.setRetryCount(BigDecimal.valueOf(retryCount));
        record.setExecStatus(BigDecimal.valueOf(execStatus));
        record.setExecStatusDesc(execStatusDesc);
        return mapper.updateByPrimaryKey(record);
    }

    /**
     *  跟新任务日志
     * */
    public Cp2ScheduleTaskLogs queryLog(){
        return mapper.selectByPrimaryKey(id);
    }

    public void setProcess(){
        this.execStatus=1;
        this.execStatusDesc="处理中";
    }
    public void setRetry(){
        this.execStatus=2;
        this.execStatusDesc="重试中";
    }
    public void setSuccess(){
        this.execStatus=3;
        this.execStatusDesc="处理成功";
    }

    public void setFail(){
        this.execStatus=4;
        this.execStatusDesc="处理失败";
    }
    public void setFail(String desc){
        this.execStatus=4;
        this.execStatusDesc=desc;
    }
}
