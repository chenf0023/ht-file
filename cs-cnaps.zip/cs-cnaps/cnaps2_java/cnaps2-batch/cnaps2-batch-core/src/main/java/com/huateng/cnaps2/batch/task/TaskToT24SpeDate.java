package com.huateng.cnaps2.batch.task;

import com.huateng.cnaps2.batch.dal.mapper.ext.ExtT24SpeDateTaskMapper;
import com.huateng.cnaps2.batch.dynamicSchedule.BaseTask;
import com.huateng.cnaps2.batch.utils.STPCheckHelperService;
import com.huateng.cnaps2.mapper.Cp2Hvps111Mapper;
import com.huateng.cnaps2.mapper.Cp2Hvps112Mapper;
import com.huateng.cnaps2.mapper.Cp2TxnMapper;
import com.huateng.cnaps2.model.Cp2Hvps111;
import com.huateng.cnaps2.model.Cp2Hvps112;
import com.huateng.cnaps2.model.Cp2Txn;
import com.huateng.cnaps2.service.common.Cnaps2Const;
import com.huateng.cnaps2.service.common.Cnaps2Dict;
import com.huateng.cpg.mapper.ext.CpgOrganMapperExt;
import com.huateng.cpg.model.CpgOrgan;
import com.huateng.cs.busi.api.model.CheckModel;
import com.huateng.cs.busi.api.model.CheckRequest;
import com.huateng.cs.busi.dal.model.CsCustTxn;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Slf4j
@Service
public class TaskToT24SpeDate extends BaseTask {
    private static final Logger logger = LoggerFactory.getLogger(TaskToT24SpeDate.class);
    static private final String BIZ_TYPE_REEXCHANGE = "A105";
    static private final String BIZ_CTGY_REEXCHANGE = "02108";

    @Resource
    private ExtT24SpeDateTaskMapper extT24SpeDateTaskMapper;
    @Resource
    private Cp2TxnMapper cp2TxnMapper;

    @Resource
    private Cp2Hvps111Mapper cp2Hvps111Mapper;
    @Resource
    private Cp2Hvps112Mapper cp2Hvps112Mapper;
    @Autowired
    private STPCheckHelperService stpCheckHelperService;

    @Override
    public void init() {
        super.init();
        super.setScheduleId("1");
    }

    @Override
    public void process() {
        logger.debug("####################[定时处理指定日期任务]####################");
         String cpgDate = "";
         List<String> brnos = extT24SpeDateTaskMapper.selectBrno();
         for(String brno : brnos){
            cpgDate = extT24SpeDateTaskMapper.selectCpgDate(brno);
         List<Cp2Txn> cp2Txns = extT24SpeDateTaskMapper.selectCp2Txn(cpgDate,brno);
          for (Cp2Txn cp2Txn:cp2Txns){
         String payerBrnobank =  extT24SpeDateTaskMapper.selectBankCode(cp2Txn.getPayerBrno());
         String payerAccBrnobank = extT24SpeDateTaskMapper.selectBankCode(cp2Txn.getPayerAccBrno());
         String payeeBrnobank =  extT24SpeDateTaskMapper.selectBankCode(cp2Txn.getPayeeBrno());
         String payeeAccBrnobank =  extT24SpeDateTaskMapper.selectBankCode(cp2Txn.getPayeeAccBrno());
            CsCustTxn csCustTxn = extT24SpeDateTaskMapper.selectCsCustTxn(cp2Txn.getCoreId());
            if (payerBrnobank == null || payerAccBrnobank == null || payeeBrnobank ==null || payeeAccBrnobank ==null) {
            log.info("not find payee or payer bankcode");
            log.info("update csCustTxn , Cp2Txn   status = 17");
            extT24SpeDateTaskMapper.updateStatusforCsCust("17","97",csCustTxn.getId());
            extT24SpeDateTaskMapper.updateStatusforCp2Txn("17","97",csCustTxn.getId());
            if (payerBrnobank == null)     extT24SpeDateTaskMapper.setNstpRemarks("付款行行号未找到",csCustTxn.getId());
            else if(payerAccBrnobank == null)  extT24SpeDateTaskMapper.setNstpRemarks("付款人开户行行号未找到",csCustTxn.getId());
            else if(payeeBrnobank == null)  extT24SpeDateTaskMapper.setNstpRemarks("收款行行号未找到",csCustTxn.getId());
            else extT24SpeDateTaskMapper.setNstpRemarks("收款人开户行行号未找到",csCustTxn.getId());
            break;
            }


        if (cp2Txn.getBizTypeCode().equals("A105")) {//判断是否是退汇业务
            //如果是退汇业务，查Cp2Txn是否有要退汇业务的原业务
            log.info(" It  is  a Return business");
            String oriId = cp2Txn.getOriId();
            if (oriId == null ) {

                extT24SpeDateTaskMapper.updateStatusforCsCust("17","97",csCustTxn.getId());
                extT24SpeDateTaskMapper.updateStatusforCp2Txn("17","97",csCustTxn.getId());
                extT24SpeDateTaskMapper.setNstpRemarks("退汇的原业务未查到",csCustTxn.getId());
                log.info("退汇的原业务未查到 end");

            }else {
                String status = extT24SpeDateTaskMapper.selectStatusByCoreId(oriId);
                if(status.equals("21")){
                    extT24SpeDateTaskMapper.updateStatusforCsCust("17","97",csCustTxn.getId());
                    extT24SpeDateTaskMapper.updateStatusforCp2Txn("17","97",csCustTxn.getId());
                    extT24SpeDateTaskMapper.setNstpRemarks("退汇的原业务已退汇",csCustTxn.getId());
                }
                Cp2Txn oricp2Txn = extT24SpeDateTaskMapper.selectCp2TxnByOriId(oriId);
                //将状态 暂存到 CUST_STATUS2
                extT24SpeDateTaskMapper.putCustStatus(oriId);
                oricp2Txn.setStatus(Cnaps2Dict.CP2_STATUS.REFUNDED.value);
                cp2TxnMapper.updateByPrimaryKeySelective(oricp2Txn);
                //更新退汇业务
                log.info("update cp2Txn");
                cp2Txn.setBizTypeCode(BIZ_TYPE_REEXCHANGE);
                cp2Txn.setBizCtgyCode(BIZ_CTGY_REEXCHANGE);
                cp2Txn.setDrct(Cnaps2Dict.DRCT_TYPE.SND.value);
                cp2Txn.setSource(Cnaps2Dict.CS_SOURCE_TYPE.T24.value);
                cp2Txn.setPkgno(oricp2Txn.getPkgno());
                cp2Txn.setOriId(oricp2Txn.getCoreId());
//                    cp2Txn.setIsnra(cp2TxnOrg.getIsnra());//是否NRA
//                    cp2Txn.setIsprivate(cp2TxnOrg.getIsprivate());//是否对私
                cp2Txn.setCurcd(oricp2Txn.getCurcd());
                cp2Txn.setAmount(oricp2Txn.getAmount());
                cp2Txn.setMdTime(getTxndate1());

                cp2Txn.setPayerBrno(oricp2Txn.getPayeeBrno());
                cp2Txn.setSndStBrno(getCnapsStBrno(oricp2Txn.getPayeeBrno()));
                cp2Txn.setPayerAccBrno(oricp2Txn.getPayeeAccBrno());
                cp2Txn.setPayerAccBrname(oricp2Txn.getPayeeAccBrname());

                cp2Txn.setPayerActno(oricp2Txn.getPayeeActno());
                cp2Txn.setPayerName(oricp2Txn.getPayeeName());
                cp2Txn.setPayeeBrno(oricp2Txn.getPayerBrno());
                cp2Txn.setRcvStBrno(getCnapsStBrno(oricp2Txn.getPayerAccBrno()));

                cp2Txn.setPayeeAccBrno(oricp2Txn.getPayerAccBrno());
                cp2Txn.setPayeeAccBrname(oricp2Txn.getPayerAccBrname());
                cp2Txn.setPayeeActno(oricp2Txn.getPayerActno());
                cp2Txn.setPayeeName(oricp2Txn.getPayerName());

                cp2Txn.setOriPkgId(oricp2Txn.getMsgId());
                cp2Txn.setOriSender(oricp2Txn.getSndStBrno());
                cp2Txn.setOriTypeCode(oricp2Txn.getBizTypeCode());
                cp2Txn.setSysCode(Cnaps2Dict.SYS_CODE.HVPS.value);
                cp2Txn.setDest(Cnaps2Dict.DEST_FLAG.CENTER.value);
                cp2Txn.setComStatus(Cnaps2Dict.COM_STATUS.NOTPROC.value);

                cp2TxnMapper.updateByPrimaryKey(cp2Txn);
                log.info("update Hvps11*");
                if (cp2Txn.getPkgno().equals("hvps.111.001.01")) {
                    Cp2Hvps111 cp2Hvps111 = extT24SpeDateTaskMapper.selectCp2Hvps111(cp2Txn.getCoreId());
                    cp2Hvps111.setDrct(Cnaps2Dict.DRCT_TYPE.SND.value);
                    cp2Hvps111.setStMtd("CLRG");
                    cp2Hvps111.setDtlNum((long) 1);
                    cp2Hvps111.setBizTypeCode(BIZ_TYPE_REEXCHANGE);
                    cp2Hvps111.setBizCtgyCode(BIZ_CTGY_REEXCHANGE);
                    cp2Hvps111.setCurcd(oricp2Txn.getCurcd());
                    cp2Hvps111.setAmount(oricp2Txn.getAmount());
                    cp2Hvps111.setFeePayType("DEBT");
                    cp2Hvps111.setPayerBrno(oricp2Txn.getPayeeBrno());
                    cp2Hvps111.setPayerStBrno(getCnapsStBrno(oricp2Txn.getPayeeBrno()));
                    cp2Hvps111.setPayerAccBrno(oricp2Txn.getPayeeAccBrno());
                    cp2Hvps111.setPayerAccBrname(oricp2Txn.getPayeeAccBrname());
                    cp2Hvps111.setPayerActno(oricp2Txn.getPayeeActno());
                    cp2Hvps111.setPayerName(oricp2Txn.getPayeeName());
                    cp2Hvps111.setPayeeBrno(oricp2Txn.getPayerBrno());
                    cp2Hvps111.setPayeeStBrno(getCnapsStBrno(oricp2Txn.getPayerBrno()));
                    cp2Hvps111.setPayeeAccBrno(oricp2Txn.getPayerAccBrno());
                    cp2Hvps111.setPayeeAccBrname(oricp2Txn.getPayerAccBrname());
                    cp2Hvps111.setPayeeActno(oricp2Txn.getPayerActno());
                    cp2Hvps111.setPayeeName(oricp2Txn.getPayerName());
                    cp2Hvps111.setReturnOriPkgId(oricp2Txn.getMsgId());
                    cp2Hvps111.setReturnOriSender(oricp2Txn.getSndStBrno());//?
                    cp2Hvps111.setReturnOriMsgType(oricp2Txn.getPkgno());
                    cp2Hvps111.setTxTime(getTxndate1());
                    cp2Hvps111.setStatTime(getTxndate1());
                    cp2Hvps111.setReturnReason(csCustTxn.getRefundReason());
//                    cp2Hvps111.setReturnReason(t24Txn1000.getReturnReason());
//                    cp2Hvps111.setResendFlag(Cnaps2Dict.RESND_FLAG.NORMAL.value);
//                        cp2Hvps111.setStatus(Cnaps2Dict.COM_STATUS.NOTPROC.value);
//                    cp2Hvps111.setTxTime(serviceUtil.getTxndate());
//                    cp2Hvps111.setStatTime(serviceUtil.getTxndate());
                    cp2Hvps111Mapper.updateByPrimaryKey(cp2Hvps111);
                } else if (cp2Txn.getPkgno().equals("hvps.112.001.0")) {
                    Cp2Hvps112 cp2Hvps112 = extT24SpeDateTaskMapper.selectCp2Hvps112(cp2Txn.getCoreId());
                    cp2Hvps112.setDrct(Cnaps2Dict.DRCT_TYPE.SND.value);
                    cp2Hvps112.setStMtd("CLRG");
                    cp2Hvps112.setBizTypeCode(BIZ_TYPE_REEXCHANGE);
                    cp2Hvps112.setBizCtgyCode(BIZ_CTGY_REEXCHANGE);
                    cp2Hvps112.setCurcd(oricp2Txn.getCurcd());
                    cp2Hvps112.setAmount(oricp2Txn.getAmount());
                    cp2Hvps112.setPayerBrno(oricp2Txn.getPayeeBrno());
                    cp2Hvps112.setPayerStBrno(getCnapsStBrno(oricp2Txn.getPayeeBrno()));
                    cp2Hvps112.setPayerAccBrno(oricp2Txn.getPayeeAccBrno());
                    cp2Hvps112.setPayerAccBrname(oricp2Txn.getPayeeAccBrname());
                    cp2Hvps112.setPayerActno(oricp2Txn.getPayeeActno());
                    cp2Hvps112.setPayerName(oricp2Txn.getPayeeName());
                    cp2Hvps112.setPayeeBrno(oricp2Txn.getPayerBrno());
                    cp2Hvps112.setPayeeStBrno(getCnapsStBrno(oricp2Txn.getPayerBrno()));
                    cp2Hvps112.setPayeeAccBrno(oricp2Txn.getPayerAccBrno());
                    cp2Hvps112.setPayeeAccBrname(oricp2Txn.getPayerAccBrname());
                    cp2Hvps112.setPayeeActno(oricp2Txn.getPayerActno());
                    cp2Hvps112.setPayeeName(oricp2Txn.getPayerName());
                    cp2Hvps112.setReturnOriPkgId(oricp2Txn.getMsgId());
                    cp2Hvps112.setReturnOriSender(oricp2Txn.getSndStBrno());//?
                    cp2Hvps112.setReturnOriMsgType(oricp2Txn.getPkgno());
                    cp2Hvps112.setReturnReason(csCustTxn.getRefundReason());
//                    cp2Hvps112.setResendFlag(Cnaps2Dict.RESND_FLAG.NORMAL.value);
////                        cp2Hvps112.setStatus(Cnaps2Dict.COM_STATUS.NOTPROC.value);
                    cp2Hvps112.setTxTime(getTxndate1());
                    cp2Hvps112.setStatTime(getTxndate1());
                    cp2Hvps112Mapper.updateByPrimaryKey(cp2Hvps112);
                }
                log.info("use  STPCheck ");
                if (!cp2Txn.getStatus().equals("17")) {
                    check(cp2Txn);
                }
            }

        } else {
            //不是退汇业务
            //检查登陆状态和系统状态
            log.info("It is not a Return Business");
            if (checkLoginStatusAndSysStatus(cp2Txn.getBrno(), "HVPS")) {

                if (!cp2Txn.getStatus().equals("17")) {
                    log.info("use  STPCheck ");
                    check(cp2Txn);
                } else {
                    log.info("分行未找到，落入总行，等待手工处理 ");
                }
            } else {
                log.info("登录状态或系统状态检查失败");
            }
        }

    }
    }}
    public String getCnapsStBrno(String payeeBrno){
        return extT24SpeDateTaskMapper.getCnapsStBrno(payeeBrno);
    }

    public void check(Cp2Txn cp2Txn){
        CheckRequest var1 = CheckRequest.request4OutSuspiciousDuplication(
                cp2Txn.getPayerActno(),
                cp2Txn.getPayeeActno(),
                cp2Txn.getPayeeBrno(),
                new Long(cp2Txn.getAmount()),
                cp2Txn.getVdate(),
                cp2Txn.getPayeeName()
        );
//        CheckRequest var2 = CheckRequest.request4OutKeyword(cp2Hvps111.getRemarks(), t24Txn1000.getRemarks2(), t24Txn1000.getMemo(),t24Txn1000.getMemo2());
        CheckRequest var3 = CheckRequest.request4OutAmountLarge(new Long(cp2Txn.getAmount()));
        CheckRequest var4 = CheckRequest.request4OutCorporate2Individual(
                cp2Txn.getCustFlag1(),
                cp2Txn.getPayeeActno(),
                cp2Txn.getPayeeName(),
                cp2Txn.getVdate(),
                new Long(cp2Txn.getAmount())
        );
        CheckRequest var5 = CheckRequest.request4OutBlackList(cp2Txn.getPayeeActno());
        CheckRequest var6 = CheckRequest.request4OutPosition(new Long(cp2Txn.getAmount()));
        CheckModel entry = new CheckModel.Builder()
                .setSource(CheckModel.CHECK_SYS.T24.value)
                .setTarget(CheckModel.CHECK_SYS.PRC.value)
                .setDirection(CheckModel.CHECK_DIRECTION.OUTWARD.value)
                .setCoreId(cp2Txn.getCoreId())
                .setMsgType(cp2Txn.getPkgno())
                .setAmount(cp2Txn.getAmount())
                .setCheckRequestMap(stpCheckHelperService.setRequestParam(var1, var3, var4, var5, var6))
                .builder();

        stpCheckHelperService.sendCheck(entry);
    }
    @Resource
    private CpgOrganMapperExt cpgOrganMapperExt;
    //檢查人行登录状态和系统状态
    public boolean checkLoginStatusAndSysStatus(String brno, String sysCode) {
        boolean isChecked = true;
        CpgOrgan cpgOrgan = cpgOrganMapperExt.selectByBankCode(brno, sysCode);
        if (!Cnaps2Const.SYSTEM_STATUS.DAYTIME.equals(cpgOrgan.getCurSysStatus()) &&
                !Cnaps2Const.SYSTEM_STATUS.CLEAR.equals(cpgOrgan.getCurSysStatus())) {
            isChecked = false;
        }
        //检查登录状态
        if (!Cnaps2Const.LOGIN_OPERATE.LOGIN.equals(cpgOrgan.getOpType())) {
            isChecked = false;
        }
        return isChecked;
    }

    public String getTxndate1(){
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
    }
    }

