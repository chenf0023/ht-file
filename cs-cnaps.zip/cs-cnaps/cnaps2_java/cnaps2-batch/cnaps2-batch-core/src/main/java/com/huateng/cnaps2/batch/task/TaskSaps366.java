package com.huateng.cnaps2.batch.task;

import com.huateng.bank.message.BnkMsg;
import com.huateng.cnaps2.batch.dynamicSchedule.BaseTask;
import com.huateng.cnaps2.batch.utils.DateUtils;
import com.huateng.cnaps2.batch.utils.SequenceUtils;
import com.huateng.cnaps2.mapper.Cp2Saps366Mapper;
import com.huateng.cnaps2.mapper.Cp2TxnMapper;
import com.huateng.cnaps2.model.Cp2Saps366;
import com.huateng.cnaps2.model.Cp2Txn;
import com.huateng.cnaps2.service.Saps366Service;
import com.huateng.cnaps2.service.common.Cnaps2Const;
import com.huateng.cnaps2.service.common.Cnaps2Dict;
import com.huateng.cpg.mapper.CpgBranchMapper;
import com.huateng.cpg.mapper.CpgOrganMapper;
import com.huateng.cpg.model.CpgBranch;
import com.huateng.cpg.model.CpgBranchExample;
import com.huateng.cpg.model.CpgOrgan;
import com.huateng.cpg.model.CpgOrganExample;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 *  定时发送报文去人行查询清算账户
 * */
@Service
public class TaskSaps366 extends BaseTask {
    private static final Logger logger = LoggerFactory.getLogger(TaskSaps366.class);

    @Resource
    private Saps366Service saps366Service;
    @Resource
    private Cp2Saps366Mapper cp2Saps366Mapper;
    @Resource
    private Cp2TxnMapper cp2TxnMapper;
    @Resource
    private CpgBranchMapper cpgBranchMapper;
    @Resource
    private CpgOrganMapper cpgOrganMapper;
    @Resource
    private SequenceUtils sequenceUtils;

    @Value("${cnaps.clear.bankcode}")
    private String clearBankCode;

    @Override
    public void init() {
        super.init();
        super.setScheduleId("1");
    }

    @Override
    public void process() {
        logger.debug("####################[定时清算账户查询]####################");
        super.setProcess();
        String id= sequenceUtils.getIdByDb("SAPS");


        CpgBranchExample branchExample=new CpgBranchExample();
        CpgBranchExample.Criteria branchCriteria=branchExample.createCriteria();
        branchCriteria.andPreBrnoIsNull();
        List<CpgBranch> branches=cpgBranchMapper.selectByExample(branchExample);
        if(branches.size()!=1){
            logger.error("总行机构设置异常");
            super.setFail("处理失败:总行机构设置异常");
            return;
        }
        CpgBranch cpgBranch=branches.get(0);

        CpgOrganExample organExample=new CpgOrganExample();
        CpgOrganExample.Criteria organCriteria=organExample.createCriteria();
        organCriteria.andBankCodeEqualTo(clearBankCode);
        organCriteria.andSysTypeEqualTo("SAPS");
        List<CpgOrgan> organs=cpgOrganMapper.selectByExample(organExample);
        if(organs.size()!=1){
            logger.error("二代机构设置异常");
            super.setFail("处理失败:二代机构设置异常");
            return;
        }
        CpgOrgan organ=organs.get(0);

        logger.debug("流水号:{},清算行号:{},CPG日期:{},SAPS日期:{}",id,clearBankCode,cpgBranch.getCpgDate(),organ.getCurSysDate());

        //清算账户信息查询录入 记录366表                                              *
        Cp2Saps366 cp2Saps366 = new Cp2Saps366();
        cp2Saps366.setId(id);
        cp2Saps366.setPkgNo("saps.366.001.01");
        cp2Saps366.setDrct(Cnaps2Dict.DRCT_TYPE.SND.value);
        cp2Saps366.setSysCode(Cnaps2Dict.SYS_CODE.SAPS.value);
        cp2Saps366.setWorkdate(cpgBranch.getCpgDate()); //工作日，需要查询一下
        cp2Saps366.setDirectSender(clearBankCode);//   发起直接参与机构
        cp2Saps366.setIndirectSender(clearBankCode);//  发起简介参与机构
        cp2Saps366.setDirectRecver(Cnaps2Const.MESSAGE.CNAPS2_CODE.NPC);     //接受直接参与机构
        cp2Saps366.setIndirectRecver(Cnaps2Const.MESSAGE.CNAPS2_CODE.NPC);   //接受参与机构
        cp2Saps366.setRemarks("");//备注
        cp2Saps366.setInqType("QT00");//查询方式
        cp2Saps366.setInqStBrno(clearBankCode);//被查人行行号/被查人清算行
        cp2Saps366.setResndFlag(Cnaps2Dict.RESND_FLAG.NORMAL.value);
        cp2Saps366.setStatus(Cnaps2Dict.COM_STATUS.NOTPROC.value);
        cp2Saps366.setSndTime(DateUtils.currentDateTimeFormat("yyyyMMddHHmmss"));
        cp2Saps366.setTxTime(DateUtils.currentDateTimeFormat("yyyyMMddHHmmss"));
        cp2Saps366.setStatTime(DateUtils.currentDateTimeFormat("yyyyMMddHHmmss"));
        cp2Saps366Mapper.insertSelective(cp2Saps366);

        //清算账户信息查询录入 记录TXN表                                              *
        Cp2Txn cp2Txn = new Cp2Txn();
        cp2Txn.setCoreId(id);
        cp2Txn.setSysCode(Cnaps2Dict.SYS_CODE.SAPS.value);
        cp2Txn.setBrno("888888");                           //机构号   待补充
        cp2Txn.setVdate(cpgBranch.getCpgDate());                                //cpg日期     待补充
        cp2Txn.setWorkdate("20210114");                             //saps系统工作日
        cp2Txn.setTxndate(DateUtils.currentDateTimeFormat("yyyyMMdd"));
        cp2Txn.setDrct(Cnaps2Dict.DRCT_TYPE.SND.value);
        cp2Txn.setSource(Cnaps2Dict.SOURCE_TYPE.CPG.value);
        cp2Txn.setDest(Cnaps2Dict.DEST_FLAG.CENTER.value);
        cp2Txn.setPkgno("saps.366.001.01");
        cp2Txn.setStatus(Cnaps2Dict.CP2_STATUS.ENTERED.value);
        cp2Txn.setComStatus(Cnaps2Dict.COM_STATUS.NOTPROC.value);
        cp2Txn.setSndStBrno(clearBankCode);//待补充
        cp2Txn.setRcvStBrno(Cnaps2Const.MESSAGE.CNAPS2_CODE.NPC);
        cp2Txn.setMdTime(DateUtils.currentDateTimeFormat("yyyyMMddHHmmss"));
        cp2Txn.setMdTlrno("system");
        cp2Txn.setEdTime(DateUtils.currentDateTimeFormat("yyyyMMddHHmmss"));
        cp2Txn.setEdTlrno("system");
        cp2TxnMapper.insertSelective(cp2Txn);

        //调用CNAPS2-SERVICE      发送366报文
        saps366Service.send(new BnkMsg(id));

        super.setSuccess();
    }
}
