package com.huateng.cnaps2.batch.utils;

import com.huateng.cs.busi.api.IHandleCpg;
import com.huateng.cs.busi.api.model.CheckModel;
import com.huateng.cs.busi.api.model.CheckRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;

/**
 * 用途：往账审核前进行STP校验
 * 使用方法：传入所有需要校验项目的CheckRequest对象
 * 注：如果解析校验结果不统一，则将解析过程交给调用者
 */
@Service
public class STPCheckHelperService {
    private static final Logger logger = LoggerFactory.getLogger(STPCheckHelperService.class);

    @Autowired
    IHandleCpg iHandleCpg;


    public CheckModel sendCheck(CheckModel entry){
        //调用校验服务
        CheckModel model = iHandleCpg.execute(entry);
        logger.debug("CheckModel: {}", model);

        return model;
    }


    public HashMap<String, CheckRequest> setRequestParam(CheckRequest... params){
        HashMap<String, CheckRequest> requestMap = new HashMap<>();
        for (CheckRequest param : params) {
            requestMap.put(param.getType(), param);
        }
        logger.debug("requestMap: {}", requestMap);
        return requestMap;
    }


}
