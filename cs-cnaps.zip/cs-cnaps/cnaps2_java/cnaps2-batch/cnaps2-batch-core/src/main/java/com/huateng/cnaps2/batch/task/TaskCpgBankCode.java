package com.huateng.cnaps2.batch.task;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.huateng.cnaps2.batch.dal.mapper.ext.ExtCp2TxnCsvMapper;
import com.huateng.cnaps2.batch.dal.model.ext.Cp2BankCode;
import com.huateng.cnaps2.batch.dynamicSchedule.BaseTask;
import com.huateng.cnaps2.batch.utils.FtpUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.*;
import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class TaskCpgBankCode extends BaseTask {
    private static final Logger logger = LoggerFactory.getLogger(TaskCpgBankCode.class);
    private static final String CSV_SEPARATOR = ",";

    @Resource
    private ExtCp2TxnCsvMapper extCp2TxnCsvMapper;


    @Override
    public void process() {
        logger.debug("####################[定时查询bankCode]####################");
        super.setProcess();
        List<Cp2BankCode> cp2BankCodes = null;
        String cpgdate = LocalDateTime.now().format( DateTimeFormatter.ofPattern("yyyyMMdd"));
        if (isLastDayOfMonth(cpgdate) && isWokrdate(cpgdate)) {
            cp2BankCodes = extCp2TxnCsvMapper.selectforCpgBankCode();
        }else if(isFirstWorkdate(cpgdate) &&lastDayIsWorkDay(cpgdate)){
            cp2BankCodes = extCp2TxnCsvMapper.selectforCpgBankCode();
        }else if(!isFirstWorkdate(cpgdate) && !isLastDayOfMonth(cpgdate) && isWokrdate(cpgdate)){
             String PreWorkdate = extCp2TxnCsvMapper.selectPreWorkdate(cpgdate)+"000000";
            cp2BankCodes= extCp2TxnCsvMapper.selectAddforCpgBankCode(PreWorkdate);
        }else{
            return;
        }
        File file = null;
        try {
            String fileName = "BankCodeAndBankName_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".csv";
            //动态生成文件和文件名
             file = new File(extCp2TxnCsvMapper.getCsvUrl() + fileName);
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
//            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName), "UTF-8"));

            StringBuffer fieldNames = new StringBuffer();
            for (Field field : Cp2BankCode.class.getDeclaredFields()) {
                JsonProperty annotation = field.getAnnotation(JsonProperty.class);
                if (null == annotation) {
                    fieldNames.append(field.getName());
                    fieldNames.append(CSV_SEPARATOR);
                }
            }
            bw.write(fieldNames.toString());
            bw.newLine();

            for (Cp2BankCode cp2BankCode : cp2BankCodes) {
                StringBuffer oneLine = new StringBuffer();
                oneLine.append("\"").append(cp2BankCode.getBankCode() + "\"");
                oneLine.append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2BankCode.getBankName().trim() + "\"");
                oneLine.append(CSV_SEPARATOR);
                oneLine.append("\"").append("20220101" + "\"");
                oneLine.append(CSV_SEPARATOR);
                oneLine.append("\"").append("20991231" + "\"");
                bw.write(oneLine.toString());
                bw.newLine();
            }
            bw.flush();
            bw.close();
            logger.info("生成Csv文件完成,地址" + file.getPath());
        } catch (UnsupportedEncodingException e) {
        } catch (FileNotFoundException e) {
        } catch (IOException e) {
        }
        try {
            logger.debug("ftp -----------------connect");
            FtpUtils.getConnect(extCp2TxnCsvMapper.getFtpaddress(), extCp2TxnCsvMapper.getFtpPort(), extCp2TxnCsvMapper.getFtpUserName(), extCp2TxnCsvMapper.getFtpUserPsd());
            logger.debug("ftp -----------------upload");
            FtpUtils.uploadFile(file.getPath(),extCp2TxnCsvMapper.getFtpUrl(),file.getName());
            logger.debug("ftp ----------------success");
            FtpUtils.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean isWokrdate(String cpgdate) {
        return extCp2TxnCsvMapper.selectFlag(cpgdate).equals("0");
    }


    public boolean isLastDayOfMonth(String str) {
       return extCp2TxnCsvMapper.selectLastDayOfMoth(str.substring(0,6)+"%").equals(str);
    }
    public boolean isFirstWorkdate(String str){
         String firstDay = str.substring(0, 6)+"01";
        return extCp2TxnCsvMapper.selectFirstWorkdate(firstDay).equals(str);
    }
    public boolean lastDayIsWorkDay(String str){
      String lastDayOfMoth = extCp2TxnCsvMapper.selectLastDayOfMoth((new Integer(str.substring(0, 6)) - 1) + "%");
      return extCp2TxnCsvMapper.selectFlag(lastDayOfMoth).equals("1");
    }
}
