package com.huateng.cnaps2.batch.task;

import com.huateng.cnaps2.batch.dal.mapper.ext.ExtCp2TxnCsvMapper;
import com.huateng.cnaps2.batch.dal.model.ext.CpgDateModel;
import com.huateng.cnaps2.batch.dynamicSchedule.BaseTask;
import com.huateng.cnaps2.batch.utils.DateUtils;
import com.huateng.cnaps2.mapper.CpgMailCfgMapper;
import com.huateng.cnaps2.mapper.CpgMailMapper;
import com.huateng.cnaps2.model.Cp2TxnExample;
import com.huateng.cnaps2.model.CpgMailCfg;
import com.huateng.cnaps2.model.CpgMailCfgExample;
import com.huateng.cnaps2.service.common.Cnaps2Dict;
import com.huateng.cpg.mapper.CpgBranchMapper;
import com.huateng.cpg.model.CpgBranch;
import com.huateng.cs.busi.api.IMailService;
import com.huateng.cs.busi.api.model.CsMailModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/*
* CPG待办事项处理定时发送邮件
* */
@Service
public class TaskMail extends BaseTask {
    private static final Logger logger = LoggerFactory.getLogger(TaskMail.class);

    @Resource
    private IMailService iMailService;
    @Resource
    private ExtCp2TxnCsvMapper extCp2TxnCsvMapper;
    @Resource
    private CpgMailCfgMapper cpgMailCfgMapper;
    @Resource
    private CpgBranchMapper cpgBranchMapper;
    @Resource
    private CpgMailMapper cpgMailMapper;
    @Override
    public void init() {
        super.init();
        super.setScheduleId("1");
    }

    @Override
    public void process() {
        logger.debug("####################[定时发送邮件]####################");
        super.setProcess();

//        CpgMailCfgExample cpgMailCfgExample = new CpgMailCfgExample();
//        CpgMailCfgExample.Criteria criteria = cpgMailCfgExample.createCriteria();
//
//        cpgMailCfgExample.setDistinct(true);
//        criteria.andEventKeyEqualTo("E004");
//        List<CpgMailCfg> cpgMailCfgs = cpgMailCfgMapper.selectByExample(cpgMailCfgExample);

        List<CpgMailCfg> cpgMailCfgs = cpgMailMapper.selectByCpgMailCfg("E004");

        //调用发送邮件模块
        for(CpgMailCfg cpgMailCfg : cpgMailCfgs) {
            String reconDate = getReconDate(cpgMailCfg.getBrno());

            if(checkCpgDate(reconDate, cpgMailCfg.getBrno())) {
                CsMailModel request = new CsMailModel();
                request.setEventKey(Cnaps2Dict.MAIL_CONFIGURATION_EVENTKEY.EVENT_03.value);
                request.setReconDate(reconDate);
                request.setBrno(cpgMailCfg.getBrno());

                iMailService.sendMailText(request);
                super.setSuccess();
            }
        }
    }

    public boolean checkCpgDate(String cpgDate, String brno) {
        logger.info("#######################检查当前系统未做完的交易##########################");
        CpgDateModel cpgDateModel = extCp2TxnCsvMapper.selectCountByCp2txn(cpgDate, brno);

        //校验
        if(!cpgDateModel.getCount9().equals("0")||!cpgDateModel.getCount10().equals("0")
                ||!cpgDateModel.getCount11().equals("0")||!cpgDateModel.getCount12().equals("0")
                ||!cpgDateModel.getCount1().equals("0")||!cpgDateModel.getCount2().equals("0")
                ||!cpgDateModel.getCount3().equals("0") ||!cpgDateModel.getCount4().equals("0")
                ||!cpgDateModel.getCount5().equals("0")||!cpgDateModel.getCount7().equals("0")) {
            logger.info("#######################当前有交易未完成，发送邮件通知##########################");
            return true;
        }
        logger.info("######################当日交易已全部完成##########################");
        return false;
    }

    public String getReconDate(String brno) {
        return cpgBranchMapper.selectByPrimaryKey(brno).getCpgDate();
    }
}
