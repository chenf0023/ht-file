package com.huateng.cnaps2.batch.dal.mapper.ext;

import com.huateng.cnaps2.batch.dal.model.ext.Cp2BankCode;
import com.huateng.cnaps2.batch.dal.model.ext.Cp2TxnToCsv;
import com.huateng.cnaps2.batch.dal.model.ext.CpgDateModel;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ExtCp2TxnCsvMapper {
    List<Cp2TxnToCsv> selectByPkgNo(@Param("cpgDate") String cpgDate);
    List<Cp2BankCode>  selectforCpgBankCode();
    String getFtpaddress();
    String getFtpUserName();
    String getFtpUserPsd();
    String getFtpUrl();
    String getFtpPort();
    String getCsvUrl();
    CpgDateModel selectCountByCp2txn(@Param("cpgDate")String cpgDate, @Param("brno")String brno);

    String queryBrno(@Param("bankCode")String bankCode, @Param("sysCode")String sysCode);


    String getCpgdate(@Param("brno")String brno);

    String selectFlag(@Param("cpgdate") String cpgdate);

    String selectFirstWorkdate(@Param("firstDay") String firstDay);

    String selectLastDayOfMoth(@Param("s") String s);

    String selectPreWorkdate(@Param("cpgdate") String cpgdate);

    List<Cp2BankCode> selectAddforCpgBankCode(@Param("preWorkdate") String preWorkdate);

    String selecttime();
}
