package com.huateng.cnaps2.batch.dal.model.ext;

import lombok.Data;

/**
 * Created with Intellij IDEA
 *
 * @Auther: linchengjie
 * @Data: 2022-01-19 10:01
 * @Description:
 */
@Data
public class ExtFaultTxn {
    private String field1;
    private String field2;
    private String field3;
    private String field4;
    private String field5;
    private String field6;
    private String field7;
}
