package com.huateng.cnaps2.batch.dal.model.ext;

import lombok.Data;

/**
 * Created with Intellij IDEA
 *
 * @Auther: linchengjie
 * @Data: 2022-01-18 18:40
 * @Description:
 */
@Data
public class ExtHvpsExcpTxn {
    private String id;
    private String orgSenderSid;
    private String pkgNo;
    private String workdate;
    private String msgId;
    private String drct;
    private String sndTime;
    private String rcvTime;
    private String status;
    private String signResult;
    private String rejectInfo;
    private long amount;
    private String orgSender;
    private String orgSenderDate;
    private String brno;
    private String vdate;
    private String txnStatus;

    private String aProcCode;
    private String eProcCode;
}
