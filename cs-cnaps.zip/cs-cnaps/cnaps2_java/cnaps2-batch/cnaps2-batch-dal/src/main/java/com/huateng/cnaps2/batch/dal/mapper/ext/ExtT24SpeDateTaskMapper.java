package com.huateng.cnaps2.batch.dal.mapper.ext;


import com.huateng.cnaps2.model.Cp2Hvps111;
import com.huateng.cnaps2.model.Cp2Hvps112;
import com.huateng.cnaps2.model.Cp2Txn;
import com.huateng.cs.busi.dal.model.CsCustTxn;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ExtT24SpeDateTaskMapper {
    List<Cp2Txn> selectCp2Txn(@Param("cpgDate") String cpgDate,@Param("brno")String brno);

    String selectBankCode(String bankCode);

    CsCustTxn selectCsCustTxn(String coreId);

    Cp2Hvps111 selectCp2Hvps111(String coreId);

    Cp2Hvps112 selectCp2Hvps112(String coreId);

    String getCnapsStBrno(@Param("brno") String brno);

    List<String> selectBrno();

    String selectCpgDate(String brno);

    void updateStatusforCsCust(@Param("status") String status,@Param("nstpType") String nstpType,@Param("id") String id);

    void updateStatusforCp2Txn(@Param("status") String status,@Param("nstpType") String nstpType,@Param("id") String id);

    void setNstpRemarks(@Param("str") String str,@Param("id")String id);

    String selectStatusByCoreId(@Param("coreId") String oriId);

    Cp2Txn selectCp2TxnByOriId(@Param("oriId")String oriId);

    void putCustStatus(@Param("oriId") String oriId);
}
