package com.huateng.cnaps2.batch.dal.model.ext;

import lombok.Data;

@Data
public class ExtAllExcpTxn {

    private String id;
    private String txnid;
    private String syscode;
    private String pkgno;
    private String status;
    private String procCode;

}
