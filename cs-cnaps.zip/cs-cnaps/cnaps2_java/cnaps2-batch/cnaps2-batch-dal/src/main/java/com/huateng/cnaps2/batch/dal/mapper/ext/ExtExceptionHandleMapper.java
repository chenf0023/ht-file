package com.huateng.cnaps2.batch.dal.mapper.ext;

import com.huateng.cnaps2.batch.dal.model.ext.*;
import com.huateng.cpg.model.CpgExceptionInf;
import com.huateng.mybatis.ext.plugin.Lock;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created with Intellij IDEA
 *
 * @Auther: linchengjie
 * @Data: 2022-01-18 18:19
 * @Description:
 */
public interface ExtExceptionHandleMapper {
    /**
     * 大额异常交易查询
     * */
    public List<ExtHvpsExcpTxn> queryHvpsExcp();
    /**
     * 小额异常交易查询
     * */
    public List<ExtBepsExcpTxn> queryBepsExcp();
    /**
     * 可疑交易查询
     * */
    public List<ExtFaultTxn> queryFaultExcp();
    /**
     *异常处理恢复
     */
    public List<ExtAllExcpTxn> ExtAllExcpTxn();

    public List<ExtAllExcpTxnOrg>ExtAllExcpTxnOrg(@Param("tableName")String tableName,@Param("id") String id);

    /**
     * 可疑交易查询 根据日期
     * */
    public List<ExtFaultTxn> queryFaultExcpByDate();
    /**
     * 获取相关交易的cpg日期和分行号     由于不同交易需要关联不同表，因此，关联表动态传入
     * */
    public List<ExtCpgDateOrg> queryCpgDateAndBrno(@Param("id")String id, @Param("pkgId")String pkgId);

    public int querySysParams(@Param("sysFlg")String sysFlg,@Param("orgNo") String orgNo,@Param("paraCode") String paraCode);

    public int updateSysParams(@Param("sysFlg")String sysFlg,@Param("orgNo")String orgNo,@Param("paraCode")String paraCode,@Param("paraValue")int paraValue);

    public int updateCpgExceptionInf(@Param("id")String id);

    public int queryCpgExceptionInf(@Param("txnid")String txnid);

    CpgExceptionInf selectByTxnid(String txnid, Lock lock);




}
