package com.huateng.cnaps2.batch.dal.model.ext;

import lombok.Data;

@Data
public class Cp2BankCode {

private String bankCode;
private String bankName;
private String effectiveDate;
private String expirationDate;
}
