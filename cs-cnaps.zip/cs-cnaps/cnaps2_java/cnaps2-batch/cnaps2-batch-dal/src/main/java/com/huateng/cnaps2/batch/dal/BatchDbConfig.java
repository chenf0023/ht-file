package com.huateng.cnaps2.batch.dal;


import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.annotation.MapperScan;
import org.mybatis.spring.annotation.MapperScans;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import javax.annotation.Resource;


@Configuration
@MapperScans({
        @MapperScan("com.huateng.cnaps2.batch.dal.mapper")
})
@PropertySource("classpath:batch-dal.properties")
public class BatchDbConfig  {

}
