package com.huateng.cnaps2.batch;

import com.huateng.service.fusion.autoconfigure.ServiceServer;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:cnaps2-batch.properties")
public class BatchProviderConfig {
    @ServiceServer("service.cnaps2-batch")
    class CsService {

    }
}
