package com.huateng.cnaps2.batch;

import com.huateng.cnaps2.batch.dto.ScheduleDto;

import java.util.Map;

public interface IBatchManager {

    public Map<String,Object> querySchedule(ScheduleDto request);

    public Map<String,Object> addSchedule(ScheduleDto request);

    public Map<String,Object> editSchedule(ScheduleDto request);

    public Map<String,Object> cancleSchedule(ScheduleDto request);
}
