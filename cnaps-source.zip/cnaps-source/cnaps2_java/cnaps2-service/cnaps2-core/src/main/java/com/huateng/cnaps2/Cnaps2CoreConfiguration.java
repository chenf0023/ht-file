package com.huateng.cnaps2;

import com.huateng.cnaps2.dal.Cnaps2DalConfiguration;
import com.huateng.cnaps2.service.util.ServiceUtil;
import com.huateng.cnaps2.sign.Cnaps2SignRepertory;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;

@ComponentScan("com.huateng.cnaps2.service")
@Import({Cnaps2SignRepertory.class, ServiceUtil.class, Cnaps2MessageConfiguration.class, Cnaps2DalConfiguration.class})
public class Cnaps2CoreConfiguration {

}
