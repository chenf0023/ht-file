package com.huateng.cnaps2.exception;

public class ReceiveExcetion extends RuntimeException {
    private byte[] org;
    private Object msg;
    private String msgNo;

    public byte[] getOrg() {
        return org;
    }

    public Object getMsg() {
        return msg;
    }

    public String getMsgNo() {
        return msgNo;
    }

    public ReceiveExcetion(Throwable cause, byte[] org, Object msg, String msgNo) {
        super(cause);
        this.org = org;
        this.msg = msg;
        this.msgNo = msgNo;
    }

    public ReceiveExcetion(String message, byte[] org, Object msg, String msgNo) {
        super(message);
        this.org = org;
        this.msg = msg;
        this.msgNo = msgNo;
    }

    @Override
    public String getMessage() {
        return "ReceiveExcetion{" +
                ", msg=" + msg +
                ", msgNo='" + msgNo + '\'' +
                "}, err:" + super.getMessage();
    }
}
