package com.huateng.cnaps2.service.bank.impl;

import com.huateng.bank.message.BnkMsg;
import com.huateng.cnaps2.bank.service.Beps383BankService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * @Description
 * @Author miracle
 * @Date 2021/11/5 10:49
 * @Version 1.0
 */
@Service
public class Beps383BankServiceImpl implements Beps383BankService {
    private static final Logger logger = LoggerFactory.getLogger(Beps383BankServiceImpl.class);
    
    @Override
    public void receive(BnkMsg bnkMsg) {
        // service code
    }
}