package com.huateng.cnaps2.service.bank.impl;

import com.huateng.bank.message.BnkMsg;
import com.huateng.cnaps2.bank.service.Ccms317_02BankService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * @Description
 * @Author miracle
 * @Date 2021/11/5 10:49
 * @Version 1.0
 */
@Service
public class Ccms317_02BankServiceImpl implements Ccms317_02BankService {
    private static final Logger logger = LoggerFactory.getLogger(Ccms317_02BankServiceImpl.class);
    
    @Override
    public void receive(BnkMsg bnkMsg) {
        // service code
    }
}