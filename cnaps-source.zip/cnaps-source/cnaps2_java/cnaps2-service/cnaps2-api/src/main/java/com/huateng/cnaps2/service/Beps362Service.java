package com.huateng.cnaps2.service;


import com.huateng.cnaps2.message.Beps_362_001_01;

public interface Beps362Service extends IReceive<Beps_362_001_01> {
}
