package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_303_001_02;

public interface Ccms303Service extends IReceive<Ccms_303_001_02>, ISend<Ccms_303_001_02>{
}
