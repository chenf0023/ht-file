package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_911_001_02;

public interface Ccms911Service extends IReceive<Ccms_911_001_02>{
}
