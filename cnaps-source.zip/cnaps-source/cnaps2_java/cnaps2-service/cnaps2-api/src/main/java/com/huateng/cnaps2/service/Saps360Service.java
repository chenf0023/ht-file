package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Saps_360_001_01;

public interface Saps360Service extends IReceive<Saps_360_001_01>{
}
