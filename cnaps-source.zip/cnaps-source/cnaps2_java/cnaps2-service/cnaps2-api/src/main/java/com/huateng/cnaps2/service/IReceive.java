package com.huateng.cnaps2.service;

public interface IReceive<T> {
    void receive(T message);
}
