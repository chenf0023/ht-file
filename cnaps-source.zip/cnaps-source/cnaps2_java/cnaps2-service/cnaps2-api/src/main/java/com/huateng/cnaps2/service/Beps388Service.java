package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_388_001_01;

public interface Beps388Service extends ISend<Beps_388_001_01> {
}
