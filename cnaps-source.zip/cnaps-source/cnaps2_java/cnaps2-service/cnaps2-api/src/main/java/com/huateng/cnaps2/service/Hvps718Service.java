package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_718_001_01;

public interface Hvps718Service extends ISend<Hvps_718_001_01> {
}
