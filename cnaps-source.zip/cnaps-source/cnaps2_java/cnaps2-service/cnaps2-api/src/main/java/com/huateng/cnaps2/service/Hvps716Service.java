package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_716_001_01;

public interface Hvps716Service extends IReceive<Hvps_716_001_01> {
}
