package com.huateng.cnaps2.service;


import com.huateng.cnaps2.message.Beps_363_001_01;

public interface Beps363Service extends IReceive<Beps_363_001_01>, ISend<Beps_363_001_01> {
}
