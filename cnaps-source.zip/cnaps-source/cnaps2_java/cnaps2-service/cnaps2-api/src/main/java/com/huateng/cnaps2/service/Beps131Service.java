package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_131_001_01;

public interface Beps131Service extends IReceive<Beps_131_001_01>, ISend<Beps_131_001_01>{
}
