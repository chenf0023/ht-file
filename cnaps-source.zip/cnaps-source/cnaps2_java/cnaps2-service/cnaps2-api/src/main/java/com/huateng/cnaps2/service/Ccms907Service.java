package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_907_001_02;

public interface Ccms907Service extends IReceive<Ccms_907_001_02>{
}
