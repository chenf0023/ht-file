package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_805_001_02;

public interface Ccms805Service extends ISend<Ccms_805_001_02> {
}
