package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_385_001_02;

public interface Beps385_02Service extends IReceive<Beps_385_001_02>, ISend<Beps_385_001_02>{
}
