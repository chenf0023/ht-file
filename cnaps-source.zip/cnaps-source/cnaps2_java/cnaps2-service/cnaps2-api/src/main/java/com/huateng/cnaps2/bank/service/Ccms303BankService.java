package com.huateng.cnaps2.bank.service;

import com.huateng.bank.message.BnkMsg;

public interface Ccms303BankService extends BankBaseService {
    void receive(BnkMsg bnkMsg);
}
