package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_711_001_01;

public interface Hvps711Service extends IReceive<Hvps_711_001_01> {
}
