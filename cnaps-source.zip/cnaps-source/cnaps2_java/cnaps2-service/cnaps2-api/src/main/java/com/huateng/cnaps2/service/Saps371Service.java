package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Saps_371_001_01;

public interface Saps371Service extends ISend<Saps_371_001_01> {
}
