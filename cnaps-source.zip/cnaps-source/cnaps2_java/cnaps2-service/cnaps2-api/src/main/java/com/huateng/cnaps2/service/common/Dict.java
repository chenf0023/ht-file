package com.huateng.cnaps2.service.common;

public class Dict {
    public String value;
    public String text;
    public String type;

    public Dict(String value, String text, String type) {
        this.value = value;
        this.text = text;
        this.type = type;
    }

    public Dict(String value, String text) {
        this.value = value;
        this.text = text;
    }

    
}
