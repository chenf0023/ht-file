package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_398_001_01;

public interface Beps398Service extends ISend<Beps_398_001_01> {
}
