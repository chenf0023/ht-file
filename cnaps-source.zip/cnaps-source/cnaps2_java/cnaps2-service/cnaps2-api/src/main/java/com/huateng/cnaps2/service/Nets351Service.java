package com.huateng.cnaps2.service;

import com.huateng.bank.message.BnkMsg;
import com.huateng.cnaps2.message.Nets_351_001_01;

public interface Nets351Service extends IReceive<Nets_351_001_01>{
}
