package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_903_001_02;

public interface Ccms903Service extends IReceive<Ccms_903_001_02>, ISend<Ccms_903_001_02>{
}
