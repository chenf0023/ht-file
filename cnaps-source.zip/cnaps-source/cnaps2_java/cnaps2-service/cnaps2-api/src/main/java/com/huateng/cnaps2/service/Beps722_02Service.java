package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_722_001_02;

public interface Beps722_02Service extends ISend<Beps_722_001_02> {
}
