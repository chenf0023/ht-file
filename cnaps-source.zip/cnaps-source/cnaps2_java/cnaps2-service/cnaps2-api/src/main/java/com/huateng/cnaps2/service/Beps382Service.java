package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_382_001_01;

public interface Beps382Service extends IReceive<Beps_382_001_01> {
}
