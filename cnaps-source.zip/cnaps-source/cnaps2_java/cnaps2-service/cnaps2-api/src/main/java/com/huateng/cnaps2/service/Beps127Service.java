package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_127_001_01;

public interface Beps127Service extends IReceive<Beps_127_001_01>, ISend<Beps_127_001_01>{
}
