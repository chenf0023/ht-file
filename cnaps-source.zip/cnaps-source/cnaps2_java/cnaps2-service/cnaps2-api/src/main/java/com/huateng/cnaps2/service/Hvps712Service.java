package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_712_001_01;

public interface Hvps712Service extends ISend<Hvps_712_001_01> {
}
