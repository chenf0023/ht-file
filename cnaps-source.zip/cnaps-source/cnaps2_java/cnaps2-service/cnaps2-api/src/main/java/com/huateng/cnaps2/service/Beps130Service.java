package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_130_001_01;

public interface Beps130Service extends IReceive<Beps_130_001_01> , ISend<Beps_130_001_01>{
}
