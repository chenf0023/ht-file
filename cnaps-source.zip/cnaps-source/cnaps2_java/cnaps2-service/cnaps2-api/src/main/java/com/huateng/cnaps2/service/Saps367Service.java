package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Saps_367_001_01;

public interface Saps367Service extends IReceive<Saps_367_001_01>{
}
