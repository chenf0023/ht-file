package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_916_001_01;

public interface Ccms916Service extends IReceive<Ccms_916_001_01>{
}
