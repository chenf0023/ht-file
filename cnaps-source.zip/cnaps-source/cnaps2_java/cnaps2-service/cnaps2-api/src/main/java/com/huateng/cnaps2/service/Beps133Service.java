package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_133_001_01;

public interface Beps133Service extends IReceive<Beps_133_001_01>, ISend<Beps_133_001_01>{
}
