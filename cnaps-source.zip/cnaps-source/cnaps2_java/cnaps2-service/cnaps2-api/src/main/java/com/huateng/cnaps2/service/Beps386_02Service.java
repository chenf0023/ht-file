package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_386_001_02;

public interface Beps386_02Service extends IReceive<Beps_386_001_02> {
}
