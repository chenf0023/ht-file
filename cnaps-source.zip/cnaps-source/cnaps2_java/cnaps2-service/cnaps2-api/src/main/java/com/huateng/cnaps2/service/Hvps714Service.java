package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_714_001_01;

public interface Hvps714Service extends ISend<Hvps_714_001_01> {
}
