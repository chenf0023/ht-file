package com.huateng.cnaps2.service;


import com.huateng.cnaps2.message.Beps_373_001_01;

public interface Beps373Service extends IReceive<Beps_373_001_01>{
}
