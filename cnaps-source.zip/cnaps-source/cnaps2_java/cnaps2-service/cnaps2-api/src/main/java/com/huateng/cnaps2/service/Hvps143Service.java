package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_143_001_01;

public interface Hvps143Service extends ISend<Hvps_143_001_01>{
}
