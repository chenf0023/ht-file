package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_931_001_03;

public interface Ccms931_03Service extends IReceive<Ccms_931_001_03>{
}
