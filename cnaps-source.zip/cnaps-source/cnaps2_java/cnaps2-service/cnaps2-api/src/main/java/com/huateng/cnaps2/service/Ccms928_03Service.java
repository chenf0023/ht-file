package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_928_001_03;

public interface Ccms928_03Service extends IReceive<Ccms_928_001_03>, ISend<Ccms_928_001_03>{
}
