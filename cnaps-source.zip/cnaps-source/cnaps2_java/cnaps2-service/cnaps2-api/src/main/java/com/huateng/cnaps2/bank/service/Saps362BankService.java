package com.huateng.cnaps2.bank.service;

import com.huateng.bank.message.BnkMsg;

public interface Saps362BankService extends BankBaseService {
    void receive(BnkMsg bnkMsg);
}
