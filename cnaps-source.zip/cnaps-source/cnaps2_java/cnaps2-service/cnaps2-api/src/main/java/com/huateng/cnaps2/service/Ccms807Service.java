package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_807_001_02;

public interface Ccms807Service extends IReceive<Ccms_807_001_02>{
}
