package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_154_001_01;

public interface Hvps154Service extends IReceive<Hvps_154_001_01>{
}
