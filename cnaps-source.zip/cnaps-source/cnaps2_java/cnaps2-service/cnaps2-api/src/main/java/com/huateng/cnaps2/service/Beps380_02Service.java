package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_380_001_02;

public interface Beps380_02Service extends IReceive<Beps_380_001_02>{
}
