package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Saps_369_001_01;

public interface Saps369Service extends IReceive<Saps_369_001_01>{
}
