package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_392_001_01;

public interface Beps392Service  extends IReceive<Beps_392_001_01>, ISend<Beps_392_001_01>{
}
