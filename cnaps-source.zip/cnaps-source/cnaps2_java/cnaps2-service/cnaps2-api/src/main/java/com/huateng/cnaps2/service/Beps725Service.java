package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Beps_725_001_01;

public interface Beps725Service extends IReceive<Beps_725_001_01>{
}
