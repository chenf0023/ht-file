package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_132_001_01;

public interface Hvps132Service extends ISend<Hvps_132_001_01> {
}
