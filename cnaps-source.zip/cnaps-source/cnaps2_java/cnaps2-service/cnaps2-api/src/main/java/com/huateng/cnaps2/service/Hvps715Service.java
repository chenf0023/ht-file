package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Hvps_715_001_01;

public interface Hvps715Service extends IReceive<Hvps_715_001_01> {
}
