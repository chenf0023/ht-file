package com.huateng.cnaps2.service;

import com.huateng.bank.message.BnkMsg;
import com.huateng.framework.service.convert.Message;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.GenericTypeResolver;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
@Slf4j
public class ISendSuperImpl  implements InitializingBean,ISendSuper {

    @Autowired
    protected List<ISend> iSendList;
    private Map<String, ISend> msgMap = new ConcurrentHashMap<>();


    @Override
    public String send(String pkgNo, String id) {
        ISend iSend = msgMap.get(pkgNo);
        if ( null == iSend ) {
            throw new RuntimeException("初始化失败"+pkgNo+"");
        }

        iSend.send(new BnkMsg(id));
        return "SUCCESS";
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        for( ISend iSend : iSendList ) {
            Class<?>[] msgClasses = GenericTypeResolver.resolveTypeArguments(iSend.getClass(), ISend.class);
            if ( msgClasses == null || msgClasses.length != 1 ) {
                continue;
            }

            Message message = msgClasses[0].getAnnotation(Message.class);
            if ( null == message ) {
                continue;
            }

            msgMap.put(message.value(), iSend);
        }
    }
}
