package com.huateng.cnaps2.service;

import com.huateng.bank.message.BnkMsg;
import com.huateng.cnaps2.message.Beps_397_001_01;

public interface Beps397Service extends IReceive<Beps_397_001_01>{
}
