package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_312_001_01;

public interface Ccms312Service extends IReceive<Ccms_312_001_01>, ISend<Ccms_312_001_01>{
}
