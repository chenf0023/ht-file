package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Saps_362_001_01;

public interface Saps362Service extends IReceive<Saps_362_001_01>{
}
