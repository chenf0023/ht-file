package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Saps_619_001_01;

public interface Saps619Service extends IReceive<Saps_619_001_01>{
}
