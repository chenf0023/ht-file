package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_315_001_01;

public interface Ccms315Service extends IReceive<Ccms_315_001_01>, ISend<Ccms_315_001_01>{
}
