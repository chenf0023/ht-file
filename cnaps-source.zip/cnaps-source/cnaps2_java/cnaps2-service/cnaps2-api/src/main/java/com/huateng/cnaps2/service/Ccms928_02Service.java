package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Ccms_928_001_02;

public interface Ccms928_02Service extends IReceive<Ccms_928_001_02>, ISend<Ccms_928_001_02>{
}
