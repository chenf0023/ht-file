package com.huateng.cnaps2.service.common;

public class Cnaps2Const {

    public class MESSAGE {
        /*版本号*/
        public final static String VERSION =   "02";       /*固定为02*/

        /*报文起止标志*/
        public final static String BEGINFLAG    =   "{H:";      /*起始标识*/
        public final static String ENDFLAG      =   "}\r\n";    /*结束标识*/

        /*来往账*/
        public class DIRECTION {
            /*传输方向*/
            public class CODE {
                public final static String OUT =   "U";        /*由行内发出*/
                public final static String IN  =   "D";        /*由NPC发出*/
            }
        }

        /*报文格式类型*/
        public class TYPE {
            public final static String XML =   "XML";      /*XML格式*/
            public final static String PKG =   "PKG";      /*PKG格式*/
            public final static String CMT =   "CMT";      /*CMT格式*/
        }

        /*报文优先级*/
        public class PRIORITY {
            public final static String HIGHEST =   "1";        /*特急*/
            public final static String HIGH    =   "2";        /*紧急*/
            public final static String NORM    =   "3";        /*普通*/
        }

        /* 长度限制 */
        public class LIMIT {
            public final static int NAME     =   60;         /*姓名长度*/
            public final static int ADDR     =   70;         /*地址长度*/
            public final static int ACTNO    =   32;         /*帐号长度*/
            public final static int MAXNAME  =   135;        /*姓名最大长度(适用于地址)*/
            public final static int MAXACTNO =   34;         /*帐号最大长度*/
        }

        public class CNAPS2_CODE {
            public static final String CCPC =   "00000000";
            public static final String NPC  =   "0000";
        }
    }

    /*借贷标志*/
    public final static String CP2_DIRCT_DEBT       =   "DEBT";     /*借记*/
    public final static String CP2_DIRCT_CRDT       =   "CRDT";     /*贷记*/

    /*查询类型*/
    public final static String INQ_TYPE_00          =   "QT00";      /*待查询明细业务不填*/
    public final static String INQ_TYPE_01          =   "QT01";      /*待查询明细业务必填*/

    /*生效类型*/
    public final static String CP2_EFFCODE_IMME     =   "EF00";      /*立即生效*/
    public final static String CP2_EFFCODE_APPOINT  =   "EF01";      /*指定日生效*/

    public class ORGAN {

        public class STATUS {
            public final static String START =  "01";
            public final static String STOP =  "02";
            public final static String MAINTENANCE =  "03";
            public final static String SERVICE =  "10";
            public final static String READY =  "00";
            public final static String CLOSE =  "20";
            public final static String CLEAR =  "30";
            public final static String END_OF_DAY =  "40";
            public final static String CUT_OFF =  "15";
        }

    }

    public class RECON {
        public final static String EQUAL = "0";  /* 对平 */
        public final static String NOT_EQUAL = "1";  /* 不平 */
        public final static String MORE = "2";  /* 行内多 */
        public final static String LESS = "3";  /* 行内少 */
        public final static String INFO_NOT_EQUAL = "4";  /* 要素不符 */
        public final static String PROCESS = "5";  /* 特使处理 */
        public final static String SPECAIL = "9";  /* 特殊 */
    }

    public final static String CP2_PARA_RECON_FINIASH       = "0";    /* 已对账 */

    public final static String CP2_PARA_HVPS_RECON_KEY      = "0167"; /* 对账 参数 KEY */
    public final static String CP2_PARA_BEPS_RECON_KEY      = "0166"; /* 对账 参数 KEY */

    public final static String CP2_PARA_SYS_TYPE_BIZ        = "00"; /* 业务类型 */
    public final static String CP2_PARA_SYS_TYPE_STP        = "01"; /* 联机处理 */
    public final static String CP2_PARA_SYS_TYPE_SYS        = "02"; /* 系统处理 */

    public final static String CP2_CHECK_DRCT_SEND          = "SR00";
    public final static String CP2_CHECK_DRCT_RECV          = "SR01";

    public final static String CP2_AUTHORITY_BIZTYPE_UNDEFINED = "0";

    public final static String REJECT_CODE_DUPLICATE_SIGN = "RJ13";

    public class CHG_TYPE {
        public final static String ADD     =   "CC00";
        public final static String CHG     =   "CC01";
        public final static String DEL     =   "CC02";
    }

    public class CP2_BIZ {
        public class REJECT_CODE {
            public final static String DUPLICATE_SIGN = "RJ13"; // 重复签约
        }
    }

    public class AUTH_MODEL {
        public final static String MESSAGE  = "AM00";
    }

    public class AGENT_PROTOCOL {
        public class INQ_REF {
            public final static String INQUIRE = "QT00";
            public final static String MODIFY = "QT01";
        }

        public class OPERATE {
            public final static String ADD    = "00"; // 新增
            public final static String CANCEL = "01"; // 取消
            public final static String DELETE = "02"; // 删除
        }

        public class STATUS {
            public final static String NOT_PROC   = "00";
            public final static String SEND       = "01";
            public final static String FAILURE    = "02";
            public final static String ACTIVE     = "03";
            public final static String INACTIVE   = "04";
        }
    }

    public class REALTIME_PROTOCOL {

        public class TYPE { // 协议区分
            public final static String FOR_312 = "00"; // 312下发的存量协议
            public final static String FOR_315 = "01"; // 351新增
        }

        public class STATUS {
            public final static String ACTIVE     = "03"; // 已生效
            public final static String TOACTIVE   = "05"; // 待生效
            public final static String INACTIVE   = "07"; // 已失效
        }

    }

    public class BIZ_STATUS {
        public final static String ACCOUNT_PAID   = "PR02";       /*已付款*/
        public final static String SUCCESS        = "PR05";       /*已成功*/
        public final static String REJECTED       = "PR09";       /*已拒绝*/
        public final static String CONFIRMED      = "PR10";       /*已确认*/
    }

    public class CPG_STATUS {
        public final static String ENTERED = "00";       /*已录入 */
        public final static String PASS    = "01";       /*审核通过*/
        public final static String REJECT  = "02";       /*审核拒绝*/
        public final static String DELETE  = "03";       /*待删除 */
        public final static String DELETED = "04";       /*已删除 */
    }

    public class DRAFT_STATUS {
        public final static String ISSUE   = "00";    /* 已签发 */
        public final static String TICKET  = "01";    /* 已出票 */
        public final static String CASHCH  = "02";    /* 已兑付 */
        public final static String RELOSS  = "03";    /* 已挂失 */
        public final static String SALETK  = "04";    /* 已销票 */
    }

    public class DRAFT_OPERATE {
        public final static String RELOSS  = "0";    /* 挂失 */
        public final static String FRLOSS  = "1";    /* 解挂 */
        public final static String CANCEL  = "2";    /* 取消 */
    }

    public class DRAFT_TYPE {
        public final static String NOTES  = "0";    /* 银行本票 */
        public final static String BILL   = "1";    /* 银行汇票 */
    }

    public class BRANCH_TYPE {
        public final static String INSIDE  = "0"; /* 内部机构 */
        public final static String CLBANK  = "1"; /* 清算行 */
    }

    public class NSTP_OPERATE {
        public final static String REEXCHANGE = "00";    /* 退汇 */
        public final static String SUSPENSE   = "01";    /* 挂账 */
        public final static String PROCESS    = "02";    /* 设为已处理 */
        public final static String ENTRY      = "03";    /* 入账修改 */
        public final static String OUT_MODIFY = "04";    /* 往帐修改 */
        public final static String NOCHECK    = "05";    /* 不STP校验 */
        public final static String FAULT      = "06";    /*置错*/
    }

    public class STP_FLAG {
        public final static String NO   = "0"; /* 手工 */
        public final static String YES  = "1"; /* 自动 */
    }

    public class STP_KEY_WORD_STATUS {
        public final static String TOACTIVE   = "00";   // 待生效
        public final static String ACTIVE   = "01";     // 已生效
        public final static String INACTIVE   = "02";   // 已失效
    }
    public class STP_ENABLE_STATUS{
        public final static String DISENABLE="0";
        public final static String ENABLE="1";
    }


    public class BIZ_TYPE {
        public final static String REEXCHANGE = "A105";    /* 退汇 */
    }

    public class BIZ_CTGY {
        public final static String REEXCHANGE = "02108";    /* 退汇 */
    }

    public class FEE_PAY_TYPE {
        public final static String DEBT =   "DEBT";     /*借记*/
        public final static String CRDT =   "CRDT";     /*贷记*/
    }

    public class CONTRACT {

        public class STATUS {
            public final static String NOEFF  = "00";     /*未生效*/
            public final static String EFFECT = "01";     /*已生效*/
            public final static String STOP   = "02";     /*已暂停*/
            public final static String CANCEL = "03";     /*已注销*/
        }

        // 协议签约回执标志
        public class RETN_FLG {
            public final static String MANAGER = "RE00"; // 协议管理回执
            public final static String RESULT  = "RE01"; // 协议授权结果回执
        }
    }

    public class MAINTAIN_TYPE {
        public final static String ADD           = "1";    /* 新增 */
        public final static String STAUSE        = "2";    /* 启用 */
        public final static String STOP          = "3";    /* 暂停 */
        public final static String CANCEL        = "4";    /* 注销 */
        public final static String EFFECT        = "5";    /* 生效 */
    }

    public class SYSTEM_STATUS {
        public final static String PREDAYTIME = "00"; /* 营业准备 */
        public final static String STOPTIME = "02";   /* 停运 */
        public final static String MAINTAIN = "03";   /* 维护 */
        public final static String DAYTIME = "10";    /* 日间 */
        public final static String CLEAR   = "30";    /* 清算窗口 */
        public final static String ENDDAY = "40";     /* 日终处理 */
    }

    public class LOGIN_OPERATE {
        public final static String LOGIN  = "OT00";    /* 登录 */
        public final static String LOGOUT = "OT01";    /* 退出 */
    }
    
    public class SND_TP_CODE {
        public final static String SENDER  = "SC00";    /* 主动发起 */
        public final static String QUERY = "SC01";    /* 查询应答 */
    }
}
