package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Saps_603_001_02;

public interface Saps603Service extends IReceive<Saps_603_001_02>{
}
