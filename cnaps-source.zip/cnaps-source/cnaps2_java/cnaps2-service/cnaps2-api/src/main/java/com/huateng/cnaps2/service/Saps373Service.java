package com.huateng.cnaps2.service;

import com.huateng.cnaps2.message.Saps_373_001_01;

public interface Saps373Service extends ISend<Saps_373_001_01> {
}
