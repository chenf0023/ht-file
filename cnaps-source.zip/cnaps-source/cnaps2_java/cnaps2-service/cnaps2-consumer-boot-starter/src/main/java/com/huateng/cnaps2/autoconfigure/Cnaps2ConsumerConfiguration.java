package com.huateng.cnaps2.autoconfigure;

import com.huateng.service.fusion.autoconfigure.ServiceClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:cnaps2-core-service.properties")
public class Cnaps2ConsumerConfiguration {

    @ServiceClient("service.cnaps2-core")
    class Cnaps2Core {

    }

    @ServiceClient("service.cnaps2-support")
    class Cnaps2Support {

    }
}
