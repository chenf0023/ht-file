package com.huateng.cnaps2.batch.dal.model.ext;

import lombok.Data;

@Data
public class ExtAllExcpTxnOrg {
    private String procCode;
    private String status;
}
