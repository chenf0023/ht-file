package com.huateng.cnaps2.batch.dal.mapper.ext;

import com.huateng.cnaps2.batch.dal.model.ext.Cp2BankCode;
import com.huateng.cnaps2.batch.dal.model.ext.Cp2TxnToCsv;

import java.util.List;

public interface ExtCp2TxnCsvMapper {
    List<Cp2TxnToCsv> selectByPkgNo();
    List<Cp2BankCode>  selectforCpgBankCode();
    String getFtpaddress();
    String getFtpUserName();
    String getFtpUserPsd();
    String getFtpUrl();
    String getFtpPort();
    String getCsvUrl();


}
