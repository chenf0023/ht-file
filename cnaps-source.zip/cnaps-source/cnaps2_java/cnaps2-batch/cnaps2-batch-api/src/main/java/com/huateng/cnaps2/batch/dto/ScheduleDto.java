package com.huateng.cnaps2.batch.dto;

public class ScheduleDto {
    private String scheduleId;//id
    private String scheduleName;//名称
    private String scheduleBean;//任务实体
    private String scheduleType;//类型
    private String scheduleExpr;//任务周期表达式
    private int status;//状态

    public String getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(String scheduleId) {
        this.scheduleId = scheduleId;
    }

    public String getScheduleName() {
        return scheduleName;
    }

    public void setScheduleName(String scheduleName) {
        this.scheduleName = scheduleName;
    }

    public String getScheduleBean() {
        return scheduleBean;
    }

    public void setScheduleBean(String scheduleBean) {
        this.scheduleBean = scheduleBean;
    }

    public String getScheduleType() {
        return scheduleType;
    }

    public void setScheduleType(String scheduleType) {
        this.scheduleType = scheduleType;
    }

    public String getScheduleExpr() {
        return scheduleExpr;
    }

    public void setScheduleExpr(String scheduleExpr) {
        this.scheduleExpr = scheduleExpr;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "ScheduleDto{" +
                "scheduleId='" + scheduleId + '\'' +
                ", scheduleName='" + scheduleName + '\'' +
                ", scheduleBean='" + scheduleBean + '\'' +
                ", scheduleType='" + scheduleType + '\'' +
                ", scheduleExpr='" + scheduleExpr + '\'' +
                ", status=" + status +
                '}';
    }
}
