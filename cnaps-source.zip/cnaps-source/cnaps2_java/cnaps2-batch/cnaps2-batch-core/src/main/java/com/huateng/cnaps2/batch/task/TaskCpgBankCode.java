package com.huateng.cnaps2.batch.task;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.huateng.cnaps2.batch.dal.mapper.ext.ExtCp2TxnCsvMapper;
import com.huateng.cnaps2.batch.dal.model.ext.Cp2BankCode;
import com.huateng.cnaps2.batch.dynamicSchedule.BaseTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.*;
import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
@Service
public class TaskCpgBankCode extends BaseTask {
    private static final Logger logger = LoggerFactory.getLogger(TaskCpgBankCode.class);
    private static final String CSV_SEPARATOR = ",";

    @Resource
    private ExtCp2TxnCsvMapper extCp2TxnCsvMapper;


    @Override
    public void process() {
        logger.debug("####################[定时查询bankCode]####################");
        super.setProcess();

        List<Cp2BankCode> cp2BankCodes = extCp2TxnCsvMapper.selectforCpgBankCode();

        try {
            String fileName = "BankCodeAndBankName_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".csv";
            //动态生成文件和文件名
            File file = new File("/Users/houshijie/IdeaProjects/config/cnaps_file/t24-comm/txncsv/" + fileName);
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
//            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName), "UTF-8"));

            StringBuffer fieldNames = new StringBuffer();
            for (Field field : Cp2BankCode.class.getDeclaredFields()) {
                JsonProperty annotation = field.getAnnotation(JsonProperty.class);
                if (null == annotation) {
                    fieldNames.append(field.getName());
                    fieldNames.append(CSV_SEPARATOR);
                }
            }
            bw.write(fieldNames.toString());
            bw.newLine();

            for (Cp2BankCode cp2BankCode : cp2BankCodes) {
                StringBuffer oneLine = new StringBuffer();
                oneLine.append("\"").append(cp2BankCode.getBankCode()+"\"");
                oneLine.append(CSV_SEPARATOR);
                oneLine.append("\"").append(cp2BankCode.getBankName().trim()+"\"");
                oneLine.append(CSV_SEPARATOR);
                bw.write(oneLine.toString());
                bw.newLine();
            }
            bw.flush();
            bw.close();
            logger.info("生成Csv文件完成,地址"+file.getPath());
        } catch (UnsupportedEncodingException e) {
        } catch (FileNotFoundException e) {
        } catch (IOException e) {
        }

    }
}
