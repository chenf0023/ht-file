package com.huateng.cnaps2.batch.dynamicSchedule;

/**
 * @Description 定时任务实体类
 * @Author miracle
 * @Date 2021/11/3 9:54
 * @Version 1.0
 */

public class ScheduleModel {
    private String scheduleId;//id
    private String scheduleName;//名称
    private String scheduleBean;//任务实体
    private String scheduleType;//类型
    private String scheduleExpr;//任务周期表达式
    private int status;//状态

    public ScheduleModel(String scheduleId, String scheduleName, String scheduleBean, String scheduleType, String scheduleExpr, int status) {
        this.scheduleId = scheduleId;
        this.scheduleName = scheduleName;
        this.scheduleBean = scheduleBean;
        this.scheduleType = scheduleType;
        this.scheduleExpr = scheduleExpr;
        this.status = status;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getScheduleBean() {
        return scheduleBean;
    }

    public void setScheduleBean(String scheduleBean) {
        this.scheduleBean = scheduleBean;
    }

    public String getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(String scheduleId) {
        this.scheduleId = scheduleId;
    }

    public String getScheduleName() {
        return scheduleName;
    }

    public void setScheduleName(String scheduleName) {
        this.scheduleName = scheduleName;
    }

    public String getScheduleType() {
        return scheduleType;
    }

    public void setScheduleType(String scheduleType) {
        this.scheduleType = scheduleType;
    }

    public String getScheduleExpr() {
        return scheduleExpr;
    }

    public void setScheduleExpr(String scheduleExpr) {
        this.scheduleExpr = scheduleExpr;
    }
}
