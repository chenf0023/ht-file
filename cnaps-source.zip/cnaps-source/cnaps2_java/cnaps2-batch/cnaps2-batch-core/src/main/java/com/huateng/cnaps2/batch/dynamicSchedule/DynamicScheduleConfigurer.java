package com.huateng.cnaps2.batch.dynamicSchedule;

import com.huateng.cnaps2.batch.dal.mapper.Cp2ScheduleTaskMapper;
import com.huateng.cnaps2.batch.dal.model.Cp2ScheduleTask;
import com.huateng.cnaps2.batch.dal.model.Cp2ScheduleTaskExample;
import com.huateng.cnaps2.batch.utils.BeanUtils;
import com.huateng.cnaps2.batch.utils.SpringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.SchedulingException;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTask;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.scheduling.config.TriggerTask;
import org.springframework.scheduling.support.CronTrigger;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;


/**
 *
 * @Description 动态定时任务配置类
 */

@Configuration
public class DynamicScheduleConfigurer implements SchedulingConfigurer {
    private static final Logger logger = LoggerFactory.getLogger(DynamicScheduleConfigurer.class);

    private final String FIELD_SCHEDULED_FUTURES = "scheduledTasks";//scheduledFutures  scheduledTasks
    private ScheduledTaskRegistrar scheduledTaskRegistrar;
    private Set<ScheduledTask> scheduledTasks = null;
    private Map<String, ScheduledTask> scheduledTaskMap = new ConcurrentHashMap<>();//维护任务容器

    @Resource
    private Cp2ScheduleTaskMapper cp2ScheduleTaskMapper;

    /**
     * @Description 定时任务配置初始化
     * @Author  miracle
     * @Date   2021/11/3 10:28
     * @Param
     * @Return
     * @Exception
     *
     */
    @Override
    public void configureTasks(ScheduledTaskRegistrar scheduledTaskRegistrar) {
        this.scheduledTaskRegistrar = scheduledTaskRegistrar;
        logger.debug("#################修改scheduler线程池################");
        //修改线程池
        ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
        threadPoolTaskScheduler.setPoolSize(10);
        threadPoolTaskScheduler.setThreadNamePrefix("task-");
        threadPoolTaskScheduler.setAwaitTerminationSeconds(60);
        threadPoolTaskScheduler.setWaitForTasksToCompleteOnShutdown(true);
        threadPoolTaskScheduler.setRemoveOnCancelPolicy(true);
        threadPoolTaskScheduler.initialize();
        scheduledTaskRegistrar.setTaskScheduler(threadPoolTaskScheduler);
        //初始化任务
        initSchedule();
    }

    private void initSchedule() {
        logger.info("#################初始化定时任务################");
        Cp2ScheduleTaskExample example=new Cp2ScheduleTaskExample();
        Cp2ScheduleTaskExample.Criteria criteria= example.createCriteria();
        criteria.andScheduleTypeEqualTo("cron");
        criteria.andStatusEqualTo(BigDecimal.valueOf(0));
        List<Cp2ScheduleTask> taskList= cp2ScheduleTaskMapper.selectByExample(example);
        logger.info("共查询:{}条任务",taskList.size());
        for (Cp2ScheduleTask model : taskList) {
            String scheduleBean = model.getScheduleBean();
            String scheduleId = model.getScheduleId();
            Runnable bean =  SpringUtils.getBean(scheduleBean);
            addTriggerTask(scheduleId,new TriggerTask(
                    bean,new CronTrigger(model.getScheduleExpr())
            ));
            logger.info("任务id:{},任务名:{},cron:{}加载成功",scheduleId,model.getScheduleName(),model.getScheduleExpr());
        }
    }

    private Set<ScheduledTask> getScheduledFutures()
    {
        if (scheduledTasks == null)
        {
            try {
                scheduledTasks = (Set<ScheduledTask>) BeanUtils.getProperty(scheduledTaskRegistrar, FIELD_SCHEDULED_FUTURES);
            } catch (NoSuchFieldException e) {
                logger.error(e.getMessage(),e);
            }
        }
        return scheduledTasks;
    }

    /**
     * 添加任务
     *
     * @param taskId
     * @param triggerTask
     */
    public void addTriggerTask(String taskId, TriggerTask triggerTask)
    {
        if (hasTask(taskId)) throw new SchedulingException("the taskId[" + taskId + "] has added.");
        if (null == triggerTask) throw new SchedulingException("the triggerTask[" + taskId + "] was null.");

        ScheduledTask scheduledTask = scheduledTaskRegistrar.scheduleTriggerTask(triggerTask);

        getScheduledFutures().add(scheduledTask);
        scheduledTaskMap.put(taskId, scheduledTask);
    }

    /**
     * 取消任务
     *
     * @param taskId
     */
    public ScheduledTask cancelTriggerTask(String taskId)
    {
        ScheduledTask future = scheduledTaskMap.get(taskId);
        if (future != null)
        {
            future.cancel();
            scheduledTaskMap.remove(taskId);
            getScheduledFutures().remove(future);
        }
        return future;
    }

    /**
     * 重置任务
     *
     * @param taskId
     * @param triggerTask
     */
    public void resetTriggerTask(String taskId, TriggerTask triggerTask)
    {
        ScheduledTask scheduledTask = cancelTriggerTask(taskId);
        if (null == scheduledTask) logger.warn("reset a empty task!");
        addTriggerTask(taskId, triggerTask);
    }

    /**
     * 任务编号
     *
     * @return
     */
    public Set<String> taskIds()
    {
        return scheduledTaskMap.keySet();
    }

    /**
     * 是否存在任务
     *
     * @param taskId
     * @return
     */
    public boolean hasTask(String taskId)
    {
        return this.scheduledTaskMap.containsKey(taskId);
    }

    /**
     * 任务调度是否已经初始化完成
     *
     * @return
     */
    public boolean inited()
    {
        return this.scheduledTaskRegistrar != null && this.scheduledTaskRegistrar.getScheduler() != null;
    }
}
