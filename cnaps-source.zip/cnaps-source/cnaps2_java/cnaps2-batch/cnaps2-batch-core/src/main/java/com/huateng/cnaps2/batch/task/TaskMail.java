package com.huateng.cnaps2.batch.task;

import com.huateng.cnaps2.batch.dynamicSchedule.BaseTask;
import com.huateng.cs.busi.api.IMailService;
import com.huateng.cs.busi.api.model.CsMailModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/*
* 定时发送邮件
* */
@Service
public class TaskMail extends BaseTask {
    private static final Logger logger = LoggerFactory.getLogger(TaskMail.class);

    @Resource
    private IMailService iMailService;

    @Override
    public void init() {
        super.init();
        super.setScheduleId("1");
    }

    @Override
    public void process() {
        logger.debug("####################[定时发送邮件]####################");
        super.setProcess();

        //微服务调用cs-busi模块的邮件服务
        CsMailModel request=new CsMailModel();
//        request.setFrom("508228839@qq.com");
        request.setFrom("notifications.cpgchinalib@credit-suisse.com");
        request.setSubJect("TEST EMAIL");
        request.setTo("yuxin.zhang@credit-suisse.com");
        request.setText("This is a test email,don't reply! Thanks.");
        iMailService.sendMailText(request);
        super.setSuccess();
    }
}
