package com.huateng.cnaps2.batch.common;

/**
 * 通用常量信息
 * 
 * @author miracle
 */
public class Constants
{
    /**
     * SimpleDateFormat 24时制
     */
    public static final String DATE_FORMAT_1_24 = "yyyy-MM-dd HH:mm:ss";

    /**
     * SimpleDateFormat 12时制
     */
    public static final String DATE_FORMAT_1_12 = "yyyy-MM-dd hh:mm:ss";
}
