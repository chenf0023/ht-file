package com.huateng.cnaps2.batch.service;

import com.huateng.cnaps2.batch.IBatchManager;
import com.huateng.cnaps2.batch.dto.ScheduleDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class BatchManagerService implements IBatchManager {

    private static final Logger logger = LoggerFactory.getLogger(BatchManagerService.class);

    @Override
    public Map<String, Object> querySchedule(ScheduleDto request) {
        logger.info("##############查询定时任务#############");
        return null;
    }

    @Override
    public Map<String, Object> addSchedule(ScheduleDto request) {
        logger.info("##############新增定时任务#############");
        return null;
    }

    @Override
    public Map<String, Object> editSchedule(ScheduleDto request) {
        logger.info("##############修改定时任务#############");
        return null;
    }

    @Override
    public Map<String, Object> cancleSchedule(ScheduleDto request) {
        logger.info("##############撤销定时任务#############");
        return null;
    }
}
