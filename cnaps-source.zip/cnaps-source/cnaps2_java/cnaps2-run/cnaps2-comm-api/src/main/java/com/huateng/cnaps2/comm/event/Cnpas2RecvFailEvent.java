package com.huateng.cnaps2.comm.event;

import com.huateng.cpg.event.ErrorEvent;

import java.util.Map;

public class Cnpas2RecvFailEvent extends ErrorEvent {
    private Map<String, String> commInfo;

    public Map <String, String> getCommInfo() {
        return commInfo;
    }

    public void setCommInfo(Map <String, String> commInfo) {
        this.commInfo = commInfo;
    }
}
