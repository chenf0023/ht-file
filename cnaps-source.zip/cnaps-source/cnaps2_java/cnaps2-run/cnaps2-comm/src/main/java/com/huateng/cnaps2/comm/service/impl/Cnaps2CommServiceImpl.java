package com.huateng.cnaps2.comm.service.impl;

import com.huateng.cnaps2.comm.service.Cnaps2CommReceiveService;
import com.huateng.cnaps2.comm.service.Cnaps2CommSendService;
import com.huateng.comm.interfaces.CommReceive;
import com.huateng.comm.interfaces.CommSend;
import com.huateng.comm.interfaces.ICommSend;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

@Controller
public class Cnaps2CommServiceImpl implements Cnaps2CommSendService {

    @CommSend("cnaps2")
    private ICommSend commSend;

    @Autowired
    private Cnaps2CommReceiveService cnaps2CommReceiveService;

    public void setCommSend(ICommSend commSend) {
        this.commSend = commSend;
    }

    public void setCnaps2CommReceiveService(Cnaps2CommReceiveService cnaps2CommReceiveService) {
        this.cnaps2CommReceiveService = cnaps2CommReceiveService;
    }

    // todo 测试接口以后删掉
    @RequestMapping("comm/receive")
    public void receive(@RequestBody byte[] message) {
        receive(message, null);
    }

    @CommReceive("cnaps2")
    public void receive(byte[] message,  Map<String, String> info) {
        cnaps2CommReceiveService.receive(message, info);
    }

    @Override
    public void send(byte[] message, Map <String, String> info) {
        commSend.send(message, info);
    }
}
